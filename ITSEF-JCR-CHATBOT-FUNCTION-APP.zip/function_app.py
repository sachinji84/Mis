import os
import logging
import json
import re
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv
import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.blob import BlobServiceClient
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.client_credential import ClientCredential
from docx import Document
from io import BytesIO
from bs4 import BeautifulSoup
import redis
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import base64

# Load environment variables from .env file
load_dotenv()

app = func.FunctionApp()

# Get environment variables
JCR_API_CLIENT_ID = os.getenv("JCR_API_CLIENT_ID")
JCR_SPO_URL = os.getenv("JCR_SPO_URL")
REDIS_HOST = os.getenv("REDIS_HOST")
REDIS_PORT = os.getenv("REDIS_PORT")
ROOT_SPO_CONFIG_LIST = os.getenv("ROOT_SPO_CONFIG_LIST")
# use configData.get("azureStorageUrl")
JCR_AZURE_STORAGE_URL = os.getenv("JCR_AZURE_STORAGE_URL")
# use configData.get("sitePageBlobContainer")
CONTAINER_JCR_SITEPAGES = os.getenv("CONTAINER_JCR_SITEPAGES")
# To be Decided for sharepoint Sitepage access
# ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "your-encryption-key")

WBG_HOME_URL = "https://worldbankgroup.sharepoint.com"
KEY_VAULT_NAME = "itspl-jcrchatbot-key-qa"


# Common function to create  the secret client
def get_key_vault_secret(secret_name):
    try:
        key_vault_uri = f"https://{KEY_VAULT_NAME}.vault.azure.net"
        credential = DefaultAzureCredential()
        secret_client = SecretClient(vault_url=key_vault_uri, credential=credential)
        secret_value = secret_client.get_secret(secret_name).value
        if secret_value:
            logging.info(f"'{secret_name}' accessed successfully from Azure Key Vault!.")
            return secret_value
        else:
            logging.info(f"{secret_name} value is empty in Key Vault.")
            raise ValueError(f"{secret_name} value not found in Key vault.")
    except Exception as e:
        logging.error(f"An error occurred while accessing {secret_name} from Azure Key Vault: {e}")
        raise RuntimeError(f"Failed to fetch secret: {secret_name}")


# Common function to initialize SharePoint client
def get_sharepoint_client(spSiteUrl):
    try:
        jcr_api_client_secret = get_key_vault_secret('jcr-client-secret')  # for testing in local comment this line
        # jcr_api_client_secret= JCR_API_CLIENT_SECRET  # for testing in local uncomment it
        client_credentials = ClientCredential(JCR_API_CLIENT_ID, jcr_api_client_secret)
        sharepoint_client = ClientContext(spSiteUrl).with_credentials(client_credentials)
        logging.info(f"SharePoint client created successfully for {spSiteUrl}.")
        return sharepoint_client
    except Exception as e:
        logging.error(f"An error occurred while initializing SharePoint client for url {spSiteUrl}: {e}")
        raise RuntimeError(f"Failed to initialize SharePoint client for {spSiteUrl}")


@app.timer_trigger(schedule="0 */5 * * * *", arg_name="myConfigtimer", run_on_startup=False, use_monitor=False)
async def fnRedisSyncTrigger(myConfigtimer: func.TimerRequest, context: func.Context) -> None:
    # Get the current timestamp and function name
    current_time = datetime.now().strftime('%Y-%m-%d-%H:%M:%S')
    function_name = context.function_name
    logging.info(f"Welcome to Azure function!! Python timer trigger function '{function_name}' invoked at {current_time}")

    if myConfigtimer.past_due:
        return  # If past due, exit
    try:
        # Connect to Azure Redis Cache
        # for testing in local comment this line
        REDIS_PASSWORD = get_key_vault_secret('redis-password')
        redis_url = f"rediss://:{REDIS_PASSWORD}@{REDIS_HOST}:{REDIS_PORT}/0"
        redis_client = redis.StrictRedis.from_url(redis_url)

        # Initialize SharePoint client with credentials
        ctx = get_sharepoint_client(JCR_SPO_URL)
        # Access the SharePoint
        targetList = ROOT_SPO_CONFIG_LIST
        targetListObj = ctx.web.lists.get_by_title(targetList)  # "ChatbotConfigurations"

        # Define the last timestamp to fetch items updated after this time
        last_timestamp = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
        # Fetch Items from SharePoint List which are Modified since last timestamp
        items = targetListObj.items.filter(f"Modified ge datetime'{last_timestamp}' and Active eq 1").order_by("Modified desc").get().execute_query()

        item_count = 0
        for item in items:
            try:
                # Extract properties with default values if they do not exist
                title = item.properties.get("Title")
                jsonConfig = item.properties.get("jsonConfig")
                # Check if values are present and raise an error if not
                if title and jsonConfig:
                    logging.info(f"Processing Item - Title: {title}, jsonConfig:{jsonConfig}")
                    # Store each Item details in Azure Redis Cache
                    dataConfig = json.loads(jsonConfig)
                    await process_config(item, redis_client)
                    item_count += 1
                else:
                    logging.error(f"Title and/or JSON Config is missing or empty on {targetList}.")
                    raise ValueError(f"Both Title and JSON Config must have values.")
            except Exception as e:
                logging.error(f"Issue in processing item from {targetList} with Title: '{title}'. Error: {str(e)}")
        logging.info(f"## Processed {item_count} items successfully from {targetList}. ##")

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        raise RuntimeError(f"ERROR while processing '{ROOT_SPO_CONFIG_LIST}'")


# #################################### comment for temp start
#         # Initialize SharePoint client with credentials
#         context = get_sharepoint_client(JCR_SPO_URL)
#         configList = context.web.lists.get_by_title(ROOT_SPO_CONFIG_LIST)
#         configItems = configList.items.filter(f"Active eq 1").order_by("Modified desc").get().execute_query()

#         # Loop through Each Config and perform document sync
#         for configItem in configItems:
#             try:
#                 configData = {}
#                 configTitle = configItem.properties.get("Title")
#                 configJson = configItem.properties.get("jsonConfig")
#                 if configTitle and configJson:
#                     logging.info(f"##### configTitle: {configTitle}, configJson:{configJson}")
#                     configData = json.loads(configJson)
#                 else:
#                     logging.error(f"Invalid Configuration found on root SharePoint list:'{ROOT_SPO_CONFIG_LIST}' for Title:'{configTitle}' ")
#                     raise ValueError("Title and jsonConfig Should not be empty.")

#                 # Initialize SharePoint client with credentials
#                 ctx = get_sharepoint_client(configData.get("sourceSPSite"))
#                 # Access the SharePoint
#                 targetList = configData.get("configSPListName")
#                 targetListObj = ctx.web.lists.get_by_title(targetList)  # "ChatbotConfigurations"

#                 # Define the last timestamp to fetch items updated after this time
#                 last_timestamp = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
#                 # Fetch Items from SharePoint List which are Modified since last timestamp
#                 items = targetListObj.items.filter(f"Modified ge datetime'{last_timestamp}' and Active eq 1").order_by("Modified desc").get().execute_query()

#                 item_count = 0
#                 for item in items:
#                     try:
#                         # Extract properties with default values if they do not exist
#                         title = item.properties.get("Title")
#                         jsonConfig = item.properties.get("jsonConfig")
#                         # Check if values are present and raise an error if not
#                         if title and jsonConfig:
#                             logging.info(f"Processing Item - Title: {title}, jsonConfig:{jsonConfig}")
#                             # Store each Item details in Azure Redis Cache
#                             await process_config(item, redis_client)
#                             item_count += 1
#                         else:
#                             logging.error("Title and/or JSON Config is missing or empty.")
#                             raise ValueError("Both Title and JSON Config must have values.")
#                     except Exception as e:
#                         logging.error(f"Issue in processing item from {targetList} with Title: '{title}'. Error: {str(e)}")

#                 logging.info(f"## Processed {item_count} items successfully from {targetList}. ##")
#             except Exception as e:
#                 logging.error(f"Issue in '{ROOT_SPO_CONFIG_LIST}' for Config key: {configData.get('key', 'Unknown')}. Error: {str(e)}")

#         logging.info(f"#### processing Completed for '{ROOT_SPO_CONFIG_LIST}' ####")

#     except Exception as e:
#         logging.error(f"An error occurred: {str(e)}")
#         raise RuntimeError(f"ERROR while processing '{ROOT_SPO_CONFIG_LIST}'")
# #################################### comment for temp End


# def encrypt_data(data, key):
#     # # Ensure the key is 32 bytes long
#     # if len(key) != 32:
#     #     raise ValueError("Encryption key must be 32 bytes long.")
#     # Generate a random 16-byte IV
#     iv = os.urandom(16)
#     # Derive a 32-byte key from the provided key
#     kdf = PBKDF2HMAC(
#         algorithm=hashes.SHA256(),
#         length=32,
#         salt=iv,
#         iterations=100000,
#         backend=default_backend()
#     )
#     key = kdf.derive(key.encode())
#     # Encrypt the data
#     cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
#     encryptor = cipher.encryptor()
#     encrypted_data = encryptor.update(data.encode()) + encryptor.finalize()
#     # Return the IV and encrypted data, both base64 encoded
#     return base64.b64encode(iv + encrypted_data).decode()


async def process_config(item, redis_client):
    try:
        # Get the details from item
        config_Json = item.properties.get("jsonConfig")
        # Parse the JSON configuration
        configDict = json.loads(config_Json)
        configKey = configDict.get("key")
        # # Encrypt the configuration data
        # encrypted_data = encrypt_data(json.dumps(configDict), ENCRYPTION_KEY)

        # Store the configuration data in Redis
        redis_client.set(f"config:{configKey}", json.dumps(configDict))
        # # Store the encrypted configuration data in Redis
        # redis_client.set(f"config:{configKey}", encrypted_data)

        logging.info(f"Configuration with key:'{configKey}' synced successfully to Azure Redis Cache.")
    except Exception as e:
        logging.error(f"An error occurred while syncing configuration key:'{configKey}' to Azure Redis Cache: {e}")
        raise RuntimeError(f"Unknown Error")


@app.timer_trigger(schedule="0 */5 * * * *", arg_name="mytimer", run_on_startup=False, use_monitor=False)
async def fnSPBlobSyncTrigger(mytimer: func.TimerRequest, context: func.Context) -> None:

    # Get the current timestamp and function name
    current_time = datetime.now().strftime('%Y-%m-%d-%H:%M:%S')
    function_name = context.function_name
    logging.info(f"Welcome to Azure function!! Python timer trigger function '{function_name}' invoked at {current_time}")

    if mytimer.past_due:
        return  # If past due, exit
    try:
        # Initialize SharePoint client with credentials
        context = get_sharepoint_client(JCR_SPO_URL)
        configList = context.web.lists.get_by_title(ROOT_SPO_CONFIG_LIST)
        configItems = configList.items.filter(f"Active eq 1").order_by("Modified desc").get().execute_query()

        # Loop through Each Config and perform document sync
        for configItem in configItems:
            try:
                configData = {}
                configTitle = configItem.properties.get("Title")
                configJson = configItem.properties.get("jsonConfig")
                if configTitle and configJson:
                    logging.info(f"##### configTitle: {configTitle}, configJson:{configJson}")
                    configData = json.loads(configJson)
                else:
                    logging.error(f"Invalid Configuration on SharePoint list:'{ROOT_SPO_CONFIG_LIST}' for Title:{configTitle}")
                    raise ValueError(f"Title and jsonConfig Should not be empty.")

                # Initialize SharePoint client with credentials
                ctx = get_sharepoint_client(configData.get("sourceSPSite"))
                # Access the SharePoint
                feedbackList = configData.get("feedbackSPList")  # "JCR-ChatBot-Feedbacks"
                feedbackListObj = ctx.web.lists.get_by_title(feedbackList)

                # Define the last timestamp to fetch items updated after this time
                last_timestamp = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
                # Fetch Items from SharePoint List which are Modified since last timestamp
                items = feedbackListObj.items.filter(f"Modified ge datetime'{last_timestamp}'").order_by("Modified desc").get().execute_query()

                fbCount = 0
                for item in items:
                    try:
                        resolution = item.properties.get("Resolution")
                        title = item.properties.get('Title')
                        if resolution:
                            logging.info(f"Item ID: {item.id}, Title: {title}, Resolution:{resolution} ")
                            await process_feedback(ctx, item, configData)
                            fbCount += 1
                    except Exception as e:
                        logging.error(f"Issue in processing feedback:{item.id} from {feedbackList}. Error: {str(e)}")
                logging.info(f"## Processed {fbCount} feedbacks successfully from {feedbackList}. ##")
            except Exception as e:
                logging.error(f"Issue in Configuration for key: {configData.get('key', 'Unknown')}. Error: {str(e)}")

        logging.info(f"#### processing Completed for '{ROOT_SPO_CONFIG_LIST}' ####")

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        raise RuntimeError(f"ERROR while processing '{ROOT_SPO_CONFIG_LIST}'")


async def process_feedback(ctx, item, configData):
    try:
        # Get the details from item
        fbId = item.properties.get("Id")
        fbResolution = item.properties.get("Resolution")
        feedbackContainer = configData.get("destinationBlobContainer") # "jcr-finance-and-administration"

        # Create a Word document
        doc = Document()
        doc.add_paragraph(fbResolution)

        # Save the document to a BytesIO object
        doc_io = BytesIO()
        doc.save(doc_io)
        doc_io.seek(0)

        # Connect to Azure Blob Storage using DefaultAzureCredential
        credential = DefaultAzureCredential()
        blob_service_client = BlobServiceClient(account_url=configData.get("azureStorageUrl"), credential=credential)
        blob_client = blob_service_client.get_blob_client(container=feedbackContainer, blob=f"{fbId}.docx")

        # Upload the document to Azure Blob Storage
        blob_client.upload_blob(doc_io, overwrite=True)
        logging.info(f"Document {fbId}.docx uploaded successfully to Azure Blob {feedbackContainer}.")
    except Exception as e:
        logging.error(f"An error occurred while uploading {fbId}.docx to Azure Blob {feedbackContainer}: {e}")
        raise RuntimeError(f"Unknown Error")


@app.timer_trigger(schedule="0 */5 * * * *", arg_name="myPagetimer", run_on_startup=False, use_monitor=False)
async def fnSPSitePagesSyncTrigger(myPagetimer: func.TimerRequest, context: func.Context) -> None:
    current_time = datetime.now().strftime('%Y-%m-%d-%H:%M:%S')
    function_name = context.function_name
    logging.info(f"Welcome to Azure function!! Python timer trigger function '{function_name}' invoked at {current_time}")

    if myPagetimer.past_due:
        return  # If past due, exit
    try:
        # Initialize SharePoint client with credentials
        ctx = get_sharepoint_client(JCR_SPO_URL)
        # Access the SharePoint
        library_title = "Site Pages"
        target_library = ctx.web.lists.get_by_title(library_title)

        last_timestamp = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
        # if there is any update in site page for last 5 min then consider it.
        items = target_library.items.filter(f"Modified ge datetime'{last_timestamp}'").order_by("Modified desc")
        ctx.load(items, ["Id", "FileLeafRef", "FileRef", "Modified", "FSObjType"]).execute_query()
        page_count = 0

        for item in items:
            is_file = item.properties.get('FSObjType') == 0
            file_name = item.properties.get('FileLeafRef')
            file_path = item.properties.get('FileRef')
            if is_file and file_name == 'Joint-Country-Representation.aspx':
                logging.info(f"Item ID: {item.id}, File Name: {file_name}, File Path: {file_path}")
                await process_page(ctx, item, CONTAINER_JCR_SITEPAGES)
                page_count += 1
        logging.info(f"#### Processed {page_count} items successfully. ####")

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")


async def process_page(ctx, item, blob_container_name):
    try:
        file_name = item.properties.get("FileLeafRef")
        file_path = item.properties.get("FileRef")
        # relative_folder_path = file_path.replace(JCR_SPO_SITEPAGE, "").lstrip("/")

        # Use regex to extract the relative folder path
        # This pattern assumes you want to capture everything after the third segment
        pattern = r"^/[^/]+/[^/]+/[^/]+/(.*)"
        match = re.match(pattern, file_path)
        relative_folder_path = match.group(1)

        # Open a binary stream for the file content
        file = item.file
        file_stream = file.open_binary_stream().execute_query()
        file_content_stream = BytesIO(file_stream.value)

        # Convert the binary stream to HTML content
        html_content = file_content_stream.getvalue().decode('utf-8')

        # # Convert HTML content to .docx
        docx_content = convert_html_to_docx(html_content)

        # Set up Azure Blob Storage client
        credential = DefaultAzureCredential()
        blob_service_client = BlobServiceClient(account_url=JCR_AZURE_STORAGE_URL, credential=credential)
        blob_path = relative_folder_path.replace(".aspx", ".docx")

        # Upload the .docx content to Azure Blob Storage
        blob_client = blob_service_client.get_blob_client(container=blob_container_name, blob=blob_path)
        blob_client.upload_blob(docx_content, overwrite=True)
        logging.info(f"SitePage {file_name} uploaded successfully as {blob_path} in Azure Blob Storage.")
    except Exception as e:
        logging.error(f"An error occurred while uploading {file_name} as {blob_path} in Azure Blob Storage: {e}")

# def fetch_html_content(file_path):
#     # url = f"{SHAREPOINT_URL}/SitePages/{file_path}"
#     url = "https://realpython.github.io/fake-jobs/"
#     # response = requests.get(url, auth=HttpNtlmAuth(SP_USERNAME, SP_PASSWORD))
#     response = requests.get(url)
#     response.raise_for_status()
#     return response.content


def convert_html_to_docx(html_content):
    doc = Document()
    soup = BeautifulSoup(html_content, 'lxml')
    for element in soup.find_all(['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li']):
        if element.name.startswith('h'):
            doc.add_heading(element.get_text(), level=int(element.name[1]))
        elif element.name == 'p':
            doc.add_paragraph(element.get_text())
        elif element.name == 'li':
            doc.add_paragraph(element.get_text(), style='ListBullet')
    byte_io = BytesIO()
    doc.save(byte_io)
    return byte_io.getvalue()


@app.timer_trigger(schedule="0 */5 * * * *", arg_name="myDoctimer", run_on_startup=False, use_monitor=False)
async def fnSPDocumentSyncTrigger(myDoctimer: func.TimerRequest, context: func.Context) -> None:
    current_time = datetime.now().strftime('%Y-%m-%d-%H:%M:%S')
    function_name = context.function_name
    logging.info(f"Welcome to Azure function!! Python timer trigger function '{function_name}' invoked at {current_time}")

    if myDoctimer.past_due:
        return  # If past due, exit
    try:
        # Initialize SharePoint client with credentials
        context = get_sharepoint_client(JCR_SPO_URL)
        configList = context.web.lists.get_by_title(ROOT_SPO_CONFIG_LIST)
        configItems = configList.items.filter(f"Active eq 1").order_by("Modified desc").get().execute_query()

        # Loop through Each Config and perform document sync
        for configItem in configItems:
            try:
                configData = {}
                configTitle = configItem.properties.get("Title")
                configJson = configItem.properties.get("jsonConfig")
                if configTitle and configJson:
                    logging.info(f"##### configTitle: {configTitle}, configJson:{configJson}")
                    configData = json.loads(configJson)
                else:
                    logging.error(f"Invalid Configuration on SharePoint list:'{ROOT_SPO_CONFIG_LIST}' for Title:{configTitle}")
                    raise ValueError(f"Title and jsonConfig Should not be empty.")

                # Initialize SharePoint client with credentials
                ctx = get_sharepoint_client(configData.get("sourceSPSite"))
                # Access the SharePoint
                sourceLibrary = configData.get("sourceLibrary")
                # Get sourceFolder if specified, else empty string
                sourceFolder = configData.get("sourceFolder", "")
                target_library = ctx.web.lists.get_by_title(sourceLibrary)

                # Define the last timestamp to fetch items updated after this time
                last_timestamp = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime('%Y-%m-%dT%H:%M:%SZ')
                # Fetch Items from SharePoint List which are Modified since last timestamp
                items = target_library.items.filter(f"Modified ge datetime'{last_timestamp}'").order_by("Modified desc")
                ctx.load(items, ["Id", "FileLeafRef", "FileRef", "Modified", "FSObjType"]).execute_query()

                doc_count = 0
                for item in items:
                    try:
                        file_path = item.properties.get('FileRef')
                        # Check if the item is within the specified sourceFolder
                        path_components = file_path.split('/')
                        if sourceFolder and sourceFolder not in path_components[:-1]:
                            continue
                        is_file = item.properties.get('FSObjType') == 0
                        file_name = item.properties.get('FileLeafRef')
                        if is_file and file_name:
                            logging.info(f"Item ID: {item.id}, File Name: {file_name}, File Path: {file_path}")
                            await process_file(ctx, item, configData, sourceFolder)
                            doc_count += 1
                    except Exception as e:
                        logging.error(f"Issue in processing file:{file_name} from {sourceLibrary}. Error: {str(e)}")
                logging.info(f"## Processed {doc_count} documents successfully from {sourceLibrary}. ##")
            except Exception as e:
                logging.error(f"Issue in Configuration for key: {configData.get('key', 'Unknown')}. Error: {str(e)}")

        logging.info(f"#### processing Completed for '{ROOT_SPO_CONFIG_LIST}' ####")
    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        raise RuntimeError(f"ERROR while processing '{ROOT_SPO_CONFIG_LIST}'")


async def process_file(ctx, item, configData, sourceFolder):
    try:
        file_name = item.properties.get("FileLeafRef")
        file_path = item.properties.get("FileRef")
        fullPath = WBG_HOME_URL + file_path

        # Open a binary stream for the file content
        file = item.file
        file_stream = file.open_binary_stream().execute_query()
        file_content_stream = BytesIO(file_stream.value)
        # relative_folder_path = file_path.replace(configData.get("rootSPDoc"), "").lstrip("/")

        # Determine the regex pattern based on whether sourceFolder is specified or not
        pattern = re.escape(sourceFolder) + r"/(.*)" if sourceFolder else r"^/[^/]+/[^/]+/[^/]+/(.*)"
        match = re.search(pattern, file_path)
        relative_folder_path = match.group(1) if match else file_path
        logging.info(f"relative_folder_path: '{relative_folder_path}'")

        # Set up Azure Blob Storage client
        credential = DefaultAzureCredential()
        blob_service_client = BlobServiceClient(account_url=configData.get("azureStorageUrl"), credential=credential)
        blob_path = relative_folder_path
        destinationContainer = configData.get("destinationBlobContainer")  # "jcr-finance-and-administration"

        # Upload the file content to Azure Blob Storage directly from the stream
        blob_client = blob_service_client.get_blob_client(container=destinationContainer, blob=blob_path)
        # blob_client.upload_blob(file_content_stream, overwrite=True)
        blob_client.upload_blob(file_content_stream, overwrite=True, metadata={"filepath": fullPath})
        logging.info(f"File {file_name} uploaded successfully as {blob_path} to Azure Blob {destinationContainer}.")
    except Exception as e:
        logging.error(f"An error occurred while uploading {file_name} as {blob_path} to Azure Blob {destinationContainer}: {e}")
        raise RuntimeError(f"Unknown Error")
