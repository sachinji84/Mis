# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)



# Azure Python Function Execution Steps in Local 
### Pre-requisites:
- Download & install [Azure Core Func Tools v4.x](https://github.com/Azure/azure-functions-core-tools/blob/v4.x/README.md#windows)
- Python >= 3.11
- pip >= 21
### Setup:
1. Clone this repository to your local machine.
2. Install dependencies by executing the following command in your terminal or command prompt:
```
pip install -r ./requirements.txt
```

### Create a local.settings.json file 
```
{
    "IsEncrypted": false,
    "Values": {
      "AzureWebJobsStorage": "DefaultEndpointsProtocol=https;AccountName=<ACCOUNT-NAME> AccountKey=<ACCOUNTKEY>core.windows.net",
      "FUNCTIONS_WORKER_RUNTIME": "python"
    }
}
````
### Running the Function App:
- To run the function app, execute the following command in your terminal or command prompt:
    ```
    func host start 
    ```
  If no functions were found, try debugging with
    ```
    func host start --python --verbose