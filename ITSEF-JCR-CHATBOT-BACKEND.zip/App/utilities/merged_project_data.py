import pandas as pd
import os

# Input and output file paths (same directory as the script)
input_folder = os.path.dirname(os.path.realpath(__file__))  # Get the current directory
output_file = os.path.join(input_folder, "merged_project_data.csv")  # Output file name

# File names
master_file = os.path.join(input_folder, "PROJECT_MASTER.csv")
sector_file = os.path.join(input_folder, "PROJECT_SECTOR.csv")
theme_file = os.path.join(input_folder, "PROJECT_THEMES.csv")

# Read the CSV files with a different encoding to avoid UnicodeDecodeError
encoding = 'ISO-8859-1'  # Or try 'windows-1252' if 'ISO-8859-1' doesn't work

df_master = pd.read_csv(master_file, encoding=encoding)  # PROJECT_MASTER file
df_sector = pd.read_csv(sector_file, encoding=encoding)  # PROJECT_SECTOR file
df_theme = pd.read_csv(theme_file, encoding=encoding)    # PROJECT_THEMES file

# Function to remove duplicates, wrap in double quotes, and return as a string representation of the array
def format_column_values(series):
    # Convert each value to a string, make it unique, and wrap it in double quotes
    unique_values = sorted(set(series))  # Remove duplicates and sort
    quoted_values = ['"{}"'.format(val) for val in unique_values]  # Wrap each value in double quotes
    return '[{}]'.format(', '.join(quoted_values))  # Join values with commas and wrap as array

# Group PROJECT_SECTOR by PROJ_ID and convert each column into a string of unique quoted values
sector_columns = [
    "SECT_CODE", "SECT_TEXT", "SECT_SHORT_NAME",
    "MAJOR_SECT_CODE", "MAJOR_SECT_SHORT_NAME", "MAJOR_SECT_LONG_NAME"
]

df_sector_grouped = df_sector.groupby("PROJ_ID")[sector_columns].agg(lambda x: format_column_values(x)).reset_index()

# Group PROJECT_THEMES by PROJ_ID, combining THEME_NAME into a string of unique quoted values
df_theme_grouped = df_theme.groupby("PROJ_ID")["THEME_NAME"].apply(lambda x: format_column_values(x)).reset_index()

# Merge the grouped PROJECT_SECTOR and PROJECT_THEMES with PROJECT_MASTER
result = pd.merge(df_master, df_sector_grouped, on="PROJ_ID", how="left")
result = pd.merge(result, df_theme_grouped, on="PROJ_ID", how="left")

# Replace NaN values (from missing merges) with empty arrays (represented as '[]')
for column in sector_columns:
    result[column] = result[column].fillna("[]")

result["THEME_NAME"] = result["THEME_NAME"].fillna("[]")

# Save the final result to a new CSV file
result.to_csv(output_file, index=False, quoting=1)  # `quoting=1` ensures that values are quoted when needed

print(f"Merged file saved successfully as {output_file}")
