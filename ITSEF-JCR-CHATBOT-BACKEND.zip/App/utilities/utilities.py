import re
# import json
# import os
# import redis


def is_safe_input(user_input):
    """
    Validate user input to ensure it is safe and doesn't include malicious code,
    SQL injection patterns, or system command manipulation.
    Additionally checks for attempts to modify the assistant's role.
    
    Args:
        user_input (str): The user-provided input to validate.

    Returns:
        bool: True if input is safe, False if unsafe.
    """
    # Block common malicious patterns
    unsafe_patterns = [
        r'<.*?>',  # HTML tags (to prevent XSS)
        r'--',      # SQL comments      
        r';',       # SQL statement separator
       # r'\/',      # Slash (to block path traversal)
        r'`',       # Backticks (potential command execution)    
        r'=',       # Equals sign (for assignment or command injections)
        r'(\bexec\b|\beval\b|\bsystem\b|\bimport\b)',  # Block execution related functions
        r'http[s]?://',  # URL patterns (to avoid redirecting to malicious sites)
        r'forget',  # Attempt to bypass previous instructions
        r'bypass',  # Attempt to bypass system restrictions
        r'administrator',  # Attempts to gain administrative control
        r'grant access'  # Attempts to request access to restricted data
    ]
    
    for pattern in unsafe_patterns:
        if re.search(pattern, user_input, re.IGNORECASE):
            return False
    return True


# def load_config(config_key):
#     """
#     Load configuration data from azure Redis and return it.
    
#     Args:
#         config_key (str): The key to fetch the configuration data from Redis.

#     Returns:
#         dict: The configuration data.
#     """
#     # Redis configuration
#     REDIS_HOST = os.getenv("REDIS_HOST", "itspl-jcrchatbot-redis-qa.redis.cache.windows.net")
#     REDIS_PORT = int(os.getenv("REDIS_PORT", "6380"))
#     REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "IOR08vCcV5cQ3nYmshh9Neh6RCPj5VszNAzCaBi5F2g=")
    
#     # Create redis client using HOST, PORT, and PASSWORD
#     redis_url = f"rediss://:{REDIS_PASSWORD}@{REDIS_HOST}:{REDIS_PORT}/0"
#     redis_client = redis.StrictRedis.from_url(redis_url)
    
#     # Fetch the data from Redis
#     json_config = redis_client.get(f"config:{config_key}")
#     if json_config is None:
#         raise Exception("configKey not found in Redis cache")
    
#     # Parse the JSON string
#     return json.loads(json_config.decode('utf-8'))