import os
import datetime
import json
from pydantic import BaseModel
from fastapi import APIRouter, HTTPException
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
import redis
from logging_config import setup_application_insights_logger
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Set up the logger
logger = setup_application_insights_logger()

# Create a router for chat history endpoints
router = APIRouter()

# Initialize Key Vault client
key_vault_name = "itspl-jcrchatbot-key-qa"
key_vault_uri = f"https://{key_vault_name}.vault.azure.net"
credential = DefaultAzureCredential()
secret_client = SecretClient(vault_url=key_vault_uri, credential=credential)

class ConfigKeyRequest(BaseModel):
    configKey: str


@router.post("/getConfig")
async def getConfig(request: ConfigKeyRequest):
    configKey = request.configKey
    try:
        # Redis configuration
        REDIS_HOST = os.getenv("REDIS_HOST")
        REDIS_PORT = int(os.getenv("REDIS_PORT"))
        # REDIS_PASSWORD = secret_client.get_secret('redis-password').value
        REDIS_PASSWORD = os.getenv("REDIS_PASSWORD")
        
        # Create redis client using HOST,PORT and PASSWORD 
        redis_url = f"rediss://:{REDIS_PASSWORD}@{REDIS_HOST}:{REDIS_PORT}/0"
        redis_client = redis.StrictRedis.from_url(redis_url)
        
        # # Create redis client using Managed Identity
        # REDIS_SCOPE = "https://redis.azure.com/.default"
        # credential = DefaultAzureCredential()
        # access_token = credential.get_token(REDIS_SCOPE).token
        # # Create a Redis client with the access token
        # redis_client = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, ssl=True, password=access_token)

        # Connect to Azure Redis Cache and fetch the data
        jsonConfig = redis_client.get(f"config:{configKey}").decode('utf-8')
        if jsonConfig is None:
            raise HTTPException(status_code=404, detail="configKey not found in Redis cache")

        # jsonConfig is a JSON string, parse it
        configData = json.loads(jsonConfig)
        # Store the attributes in the config (for demonstration, we just log them)
        logger.info(f"redis cache accessed successfully for configKey {configKey}: {configData} ")

        return configData
    
    except Exception as e:
        logger.error(f"Unexpected error retrieving configKey {configKey} from Redis: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")
