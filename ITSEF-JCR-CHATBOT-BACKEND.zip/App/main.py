import json
import logging
import re
from fastapi import FastAPI, status, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from datetime import datetime
from fastapi.responses import JSONResponse
from fastapi.requests import Request
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai import AzureOpenAI
from dotenv import load_dotenv
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '../App'))
from logging_config import setup_application_insights_logger
from utilities.utilities import is_safe_input
from chat_history import router as chat_history_router 
from chat_focus import router as chat_focus_router
from get_config import router as get_config_router
from dotenv import load_dotenv

load_dotenv(os.path.dirname(__file__)+"/.env")

logger = setup_application_insights_logger()

description = """
Sample app to demonstrate file upload and download with FastAPI
"""
app = FastAPI(title="JCRChatBot",
              description=description,
              version="0.1")
app.include_router(get_config_router, prefix="/get_config", tags=["Get Config"])
app.include_router(chat_history_router, prefix="/chat_history", tags=["Chat History"])
app.include_router(chat_focus_router, prefix="/chat_focus", tags=["Chat Focus"])

@app.get("/")
async def hello():
    logger.info("Hello endpoint accessed")
    return "Welcome to FastAPI"

@app.get("/Hello")
async def hello_endpoint():
    logger.info("Hello endpoint accessed")
    return f"Welcome to JCR"

# from fastapi.middleware.cors import CORSMiddleware
# origins = [
#     "http://localhost:4200",  # Frontend origin
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # Origins allowed to make requests
#     allow_credentials=True,  # Allow cookies to be included
#     allow_methods=["*"],  # HTTP methods allowed
#     allow_headers=["*"],  # Headers allowed
# )



class HealthCheck(BaseModel):
    """Response model to validate and return when performing a health check."""

@app.get(
    "/health",
    tags=["healthcheck"],
    summary="Perform a Health Check",
    response_description="Return HTTP Status Code 200 (OK)",
    status_code=status.HTTP_200_OK,
    response_model=HealthCheck,
)
def get_health() -> HealthCheck:
    logger.info("Health check performed")
    return HealthCheck(status="OK")

@app.get("/health2")
async def health_check(request: Request):
    deployed_timestamp = get_deployed_timestamp()
    current_time = get_current_time()
    return JSONResponse(content={"message": "Health check passed", "deployed_timestamp": deployed_timestamp, "current_time": current_time})

def get_deployed_timestamp():
    file_path = os.path.abspath(__file__)
    timestamp = os.path.getmtime(file_path)
    return datetime.fromtimestamp(timestamp).isoformat()

def get_current_time():
    return datetime.now().isoformat()

class ChatRequest(BaseModel):
    messages: list
    jcrIndex: str

@app.post("/chatapi", response_class=StreamingResponse, responses={200: {"description": "Streamed response"}})
async def send_request(request: ChatRequest):
    token_provider = get_bearer_token_provider(DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default")
    api_version = "2024-05-01-preview"

    client = AzureOpenAI(
        api_version=api_version,
        azure_endpoint=os.getenv('CHATBOT_AZURE_OPENAI_ENDPOINT'),
        azure_ad_token_provider=token_provider,
    )

    user_message = request.messages[-1]["content"]
    if not is_safe_input(user_message):
        logger.warning("Unsafe input detected")
        return JSONResponse(content={"error": "Unsafe input detected."}, status_code=400)

    def generate_response():
        completion = client.chat.completions.create(
            model="gpt-4o",
            messages=request.messages,
            max_tokens=4000,
            temperature=0,
            top_p=1,
            frequency_penalty=0.1,
            presence_penalty=0,
            stop=None,
            extra_body={
                "data_sources": [
                    {
                        "type": "azure_search",
                        "parameters": {
                            "endpoint": os.getenv('CHABOT_SEARCH_ENDPOINT'),
                            "index_name": request.jcrIndex, #os.getenv('CHATBOT_JCR_SEARCH_INDEX') ,
                            "authentication": {
                                "type": "system_assigned_managed_identity"
                            }
                        }
                    }
                ]
            },
            stream=True,
        )
        logger.info("Completion created successfully")

        citations = []
        intent = []
        for event in completion:
            if event.choices:  # Access `content` directly
                if hasattr(event.choices[0].delta, "model_extra") and citations.__len__() == 0:
                    model_extra = event.choices[0].delta.model_extra
                    context = model_extra.get('context', {})
                    citations = context.get('citations', [])
                    intent = context.get('intent', [])
                if event.choices[0].delta.content:
                    yield event.choices[0].delta.content

        yield '<<>>'
        yield json.dumps({"citations": citations, "intent": intent})

    try:
        return StreamingResponse(generate_response(), media_type="text/plain")
    except Exception as e:
        logger.error(f"Error creating completion: {e}")
        raise e

@app.post("/followupprompts")
async def followup_prompts(request: ChatRequest):
    token_provider = get_bearer_token_provider(DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default")
    api_version = "2024-05-01-preview"

    client = AzureOpenAI(
        api_version=api_version,
        azure_endpoint=os.getenv('CHATBOT_AZURE_OPENAI_ENDPOINT'),
        azure_ad_token_provider=token_provider,
    )

    completion = client.chat.completions.create(
        model="gpt-4o",
        messages=request.messages,
        max_tokens=800,
        temperature=0,
        top_p=0.95,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None,
        extra_body={
            "data_sources": [
                {
                    "type": "azure_search",
                    "parameters": {
                        "endpoint": os.getenv('CHABOT_SEARCH_ENDPOINT'),
                        "index_name": request.jcrIndex, #os.getenv('CHATBOT_JCR_SEARCH_INDEX'),
                        "authentication": {
                            "type": "system_assigned_managed_identity"
                        }
                    }
                }
            ]
        },
    )
    logger.info("Follow-up prompts generated successfully")
    return completion.choices[0].message.content
