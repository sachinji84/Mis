import pandas as pd
import os
import json

def read_csv_with_encoding(file_path):
    try:
        return pd.read_csv(file_path, encoding="utf-8")
    except UnicodeDecodeError:
        return pd.read_csv(file_path, encoding="latin-1")

def process_files():
    # Define the folder where files are located
    folder_path = os.path.dirname(os.path.abspath(__file__))

    # Load the data files
    wb_staff = read_csv_with_encoding(os.path.join(folder_path, 'WB_STAFF_V2.csv'))
    country = read_csv_with_encoding(os.path.join(folder_path, 'COUNTRY.csv'))
    peer_reviewer = read_csv_with_encoding(os.path.join(folder_path, 'PEER_REVIEWER_COMBINE.csv'))
    staff_skillfinder = read_csv_with_encoding(os.path.join(folder_path, 'STAFF_SKILLFINDER.csv'))
    merged_project_data = read_csv_with_encoding(os.path.join(folder_path, 'merged_project_data.csv'))

    # Ensure UPI columns are of the same type (convert to string)
    wb_staff['UPI'] = wb_staff['UPI'].astype(str)
    country['CNTRY_CDE'] = country['CNTRY_CDE'].astype(str)
    peer_reviewer['UPI'] = peer_reviewer['UPI'].astype(str)
    staff_skillfinder['UPI'] = staff_skillfinder['UPI'].astype(str)
    merged_project_data['PROJ_ID'] = merged_project_data['PROJ_ID'].astype(str)
    peer_reviewer['ProjectID'] = peer_reviewer['ProjectID'].astype(str)

    # Check for required columns in WB_STAFF_V2
    if 'COUNTRY_CODE' not in wb_staff.columns:
        raise KeyError("'COUNTRY_CODE' column is missing in WB_STAFF_V2.csv")

    # Handle missing values in COUNTRY_CODE
    wb_staff['COUNTRY_CODE'] = wb_staff['COUNTRY_CODE'].fillna('')

    # Prepare AREAS_OF_EXPERTISE as an array split by '~~'
    staff_skillfinder['AREAS_OF_EXPERTISE'] = staff_skillfinder['AREAS_OF_EXPERTISE'].fillna('')
    staff_skillfinder['AREAS_OF_EXPERTISE_ARRAY'] = staff_skillfinder['AREAS_OF_EXPERTISE'].apply(lambda x: x.split('~~'))

    # Merge PEER_REVIEWER_COMBINE with STAFF_SKILLFINDER to add AREAS_OF_EXPERTISE_ARRAY
    peer_reviewer = peer_reviewer.merge(
        staff_skillfinder[['UPI', 'AREAS_OF_EXPERTISE_ARRAY']],
        on='UPI',
        how='left'
    )

    # Add COUNTRY_CODE to PEER_REVIEWER_COMBINE by merging with WB_STAFF_V2
    peer_reviewer = peer_reviewer.merge(
        wb_staff[['UPI', 'JOB_CODE_DESCR', 'LOCATION', 'WORK_ALPHA', 'ADMIN_ALPHA','DIVISION', 'ORG_NAME', 'WORK_MOC']],
        on='UPI',
        how='left'
    )

    # Add WB_REGION_CDE, WB_REGION_NME, and CNTRY_SHORT_NAME using COUNTRY_CODE and COUNTRY.csv
    if not all(col in country.columns for col in ['CNTRY_CDE', 'WB_REGION_CDE', 'WB_REGION_NME', 'CNTRY_SHORT_NAME']):
        raise KeyError("One or more required columns are missing in COUNTRY.csv")

    peer_reviewer = peer_reviewer.merge(
        country[['CNTRY_CDE']],
        left_on='COUNTRY_CODE',
        right_on='CNTRY_CDE',
        how='left'
    )

    # Drop CNTRY_CDE as it is no longer needed
    peer_reviewer = peer_reviewer.drop(columns=['CNTRY_CDE'])

    # Merge PEER_REVIEWER_COMBINE with merged_project_data to add MAJOR_SECT_LONG_NAME and THEME_NAME
    peer_reviewer = peer_reviewer.merge(
        merged_project_data[['PROJ_ID', 'MAJOR_SECT_LONG_NAME', 'THEME_NAME']],
        left_on='ProjectID',
        right_on='PROJ_ID',
        how='left'
    )

    # Drop PROJ_ID as it is no longer needed
    peer_reviewer = peer_reviewer.drop(columns=['PROJ_ID'])

    # Remove AREAS_OF_EXPERTISE_SKILLS column if it exists
    if 'AREAS_OF_EXPERTISE_SKILLS' in peer_reviewer.columns:
        peer_reviewer = peer_reviewer.drop(columns=['AREAS_OF_EXPERTISE_SKILLS'])

    # Rename AreasOfExpertise to VettedForPeerReview
    if 'AreasOfExpertise' in peer_reviewer.columns:
        peer_reviewer = peer_reviewer.rename(columns={'AreasOfExpertise': 'VettedForPeerReview'})

    # Update CombinedRowData column to form a JSON string
    def update_combined_row_data(row):
        data = {
            "UPI": row['UPI'] if pd.notna(row['UPI']) else None,
            "Areas of Expertise": row['AREAS_OF_EXPERTISE_ARRAY'] if isinstance(row['AREAS_OF_EXPERTISE_ARRAY'], list) else [],
            "Region Code": row['WB_REGION_CDE'] if 'WB_REGION_CDE' in row and pd.notna(row['WB_REGION_CDE']) else None,
            "Region Name": row['WB_REGION_NME'] if 'WB_REGION_NME' in row and pd.notna(row['WB_REGION_NME']) else None,
            "Country Name": row['CNTRY_SHORT_NAME'] if 'CNTRY_SHORT_NAME' in row and pd.notna(row['CNTRY_SHORT_NAME']) else None,
            "Country Code": row['COUNTRY_CODE'] if 'COUNTRY_CODE' in row and pd.notna(row['COUNTRY_CODE']) else None,
            "Job Title": row['JOB_CODE_DESCR'] if 'JOB_CODE_DESCR' in row and pd.notna(row['JOB_CODE_DESCR']) else None,
            "Official Unit": row['WORK_ALPHA'] if 'WORK_ALPHA' in row and pd.notna(row['WORK_ALPHA']) else None,
            "Practice": row['PracticeName'] if 'PracticeName' in row and pd.notna(row['PracticeName']) else None,
            "Sector": row['MAJOR_SECT_LONG_NAME'] if 'MAJOR_SECT_LONG_NAME' in row and pd.notna(row['MAJOR_SECT_LONG_NAME']) else None,
            "Theme": row['THEME_NAME'] if 'THEME_NAME' in row and pd.notna(row['THEME_NAME']) else None,
            "Vetted For Peer Review": row['VettedForPeerReview'] if 'VettedForPeerReview' in row and pd.notna(row['VettedForPeerReview']) else None
        }
        for col in peer_reviewer.columns:
            if col not in [
               'VettedForPeerReview', 'PracticeName', 'JOB_CODE_DESCR', 'WORK_ALPHA', 'UPI', 'AREAS_OF_EXPERTISE_ARRAY', 'WB_REGION_CDE', 'WB_REGION_NME', 'CNTRY_SHORT_NAME', 'COUNTRY_CODE', 'CombinedRowData', 'MAJOR_SECT_LONG_NAME', 'THEME_NAME']:
                data[col] = row[col] if pd.notna(row[col]) else None
            json_string = json.dumps(data)  # This ensures it is stored as a string with curly braces
            #string1 = "Hello"
            string2 = "  }"
            result = f"{str(json_string)}{string2}"
            return  result # Return the JSON string

    peer_reviewer['CombinedRowData'] = peer_reviewer.apply(update_combined_row_data, axis=1)

    # Export the resulting data to a new CSV
    output_file = os.path.join(folder_path, 'PEER_REVIEWER_COMBINE_PROCESSED.csv')
    peer_reviewer.to_csv(output_file, index=False)

    print(f"Processed file saved as '{output_file}'")

if __name__ == "__main__":
    process_files()