from fastapi import APIRouter, HTTPException
from azure.search.documents import SearchClient
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from dotenv import load_dotenv
import uuid
import datetime
import os
from pydantic import BaseModel
from logging_config import setup_application_insights_logger
from office365.runtime.auth.client_credential import ClientCredential
from office365.sharepoint.client_context import ClientContext
from typing import List, Optional, Dict, Any

# Load environment variables from .env file
load_dotenv()

# Set up the logger
logger = setup_application_insights_logger()

# Create a router for chat history endpoints
router = APIRouter()

# Initialize Key Vault client
key_vault_name = "itspl-jcrchatbot-key-qa"
key_vault_uri = f"https://{key_vault_name}.vault.azure.net"
credential = DefaultAzureCredential()
secret_client = SecretClient(vault_url=key_vault_uri, credential=credential)

class SaveMessageRequest(BaseModel):
    message_id: str
    session_id: str
    user_id: str
    chatbot_name: str
    content: str  
    chatMessagesIndex: str
    focus: List[str] = None

@router.post("/message")
async def save_message(request: SaveMessageRequest):
    """
    Save a chat message to Azure Search.
    """
    client = SearchClient(endpoint=os.getenv('CHABOT_SEARCH_ENDPOINT'), 
                          index_name=request.chatMessagesIndex, 
                          credential=credential)
    
    message_data = {
        "message_id": request.message_id,
        "session_id": request.session_id,
        "user_id": request.user_id,
        "focus": request.focus,
        "chatbot_name": request.chatbot_name,
        "content": request.content,
        "timestamp": datetime.datetime.now().isoformat() + "Z"
    }

    try:
        result = client.upload_documents(documents=[message_data])
        logger.info(f"Message saved to Azure Search: {message_data}")
        return {"status": "success", "result": result}
    except Exception as e:
        logger.error(f"Error saving message: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/session/{chatbot_name}/{session_id}/{chatMessagesIndex}/history")
async def fetch_messages(chatbot_name: str, session_id: str, chatMessagesIndex: str):
    """
    Fetch chat history for a given session and chatbot.
    """
    client = SearchClient(endpoint=os.getenv('CHABOT_SEARCH_ENDPOINT'), 
                          index_name=chatMessagesIndex, #'chat_messages', 
                          credential=credential)
    
    try:
        results = client.search(
            search_text="",
            filter=f"session_id eq '{session_id}' and chatbot_name eq '{chatbot_name}'",
            order_by="timestamp asc"
        )
        logger.info(f"Fetched chat history for session: {session_id} and chatbot: {chatbot_name}")
        return [result for result in results]
    except Exception as e:
        logger.error(f"Error fetching chat history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/user/{chatbot_name}/{user_id}/{chatSessionsIndex}/sessions")
async def list_sessions(chatbot_name:str, user_id: str, chatSessionsIndex: str):
    """
    List all chat sessions for a given user.
    """
    client = SearchClient(endpoint=os.getenv('CHABOT_SEARCH_ENDPOINT'), 
                          index_name=chatSessionsIndex, #"chat_sessions", 
                          credential=credential)
    
    try:
        results = client.search(
            search_text="",
            filter=f"chatbot_name eq '{chatbot_name}' and user_id eq '{user_id}'",
            order_by="created_at desc"
        )
        logger.info(f"Listed chat sessions for user: {user_id}")
        return [result for result in results]
    except Exception as e:
        logger.error(f"Error listing sessions for user {user_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class CreateSessionRequest(BaseModel):
    user_id: str
    chatbot_name: str
    first_query: str
    chatSessionsIndex: str
    session_name: str
    session_id: Optional[str] = None
    

@router.post("/session")
async def create_session(request: CreateSessionRequest):
    """
    Create a new chat session in the Azure Search index.
    """
    client = SearchClient(endpoint=os.getenv('CHABOT_SEARCH_ENDPOINT'), 
                          index_name=request.chatSessionsIndex, 
                          credential=credential)
    
    # Generate session_id
    if not request.session_id:
        session_id = str(uuid.uuid4())  # Unique session ID
    else:
        session_id = request.session_id

    if not request.session_name:
        session_name = request.first_query[:30]
    else:
        session_name = request.session_name

    # Create session data
    session_data = {
        "session_id": session_id,
        "user_id": request.user_id,
        "chatbot_name": request.chatbot_name,
        "session_name": session_name,
        "session_first_query": request.first_query,
        "created_at": datetime.datetime.now().isoformat() + "Z"
    }

    try:
        # Save session to Azure Search
        result = client.upload_documents(documents=[session_data])
        logger.info(f"New session created: {session_data}")
        return {"status": "success", "session_id": session_id, "session_name": request.session_name}
    except Exception as e:
        logger.error(f"Error creating session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class FeedbackRequest(BaseModel):
    message_id: str
    chatMessagesIndex: str
    is_liked: bool = None
    is_disliked: bool = None
    dislikeinfo: dict = None
    is_email: bool = None
    emailInfo: dict = None
    
@router.post("/message/feedback")
async def update_message_feedback(feedback: FeedbackRequest):
    """
    Update the like, dislike or email feedback for a specific message in Azure Search and 
    send an email if disliked or email selected.
    """
    client = SearchClient(endpoint=os.getenv('CHABOT_SEARCH_ENDPOINT'), 
                          index_name=feedback.chatMessagesIndex, #chat_messages', 
                          credential=credential)

    try:
        # Retrieve the existing message
        result = client.get_document(key=feedback.message_id)
        if not result:
            logger.warning(f"Message with ID {feedback.message_id} not found")
            raise HTTPException(status_code=404, detail="Message not found")

        # Update the fields
        if feedback.is_liked is not None:
            result["isLiked"] = feedback.is_liked
        if feedback.is_disliked is not None:
            result["isDisLiked"] = feedback.is_disliked
        if feedback.is_email is not None:
            result["isEmail"] = feedback.is_email            

        # Upload the updated document
        update_result = client.upload_documents(documents=[result])

        # Send feedback if disliked or email selected
        if feedback.is_disliked or feedback.is_email:
            send_feedback_to_sharepoint(feedback)

        logger.info(f"Message feedback updated: {feedback}")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Error updating message feedback: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def send_feedback_to_sharepoint(feedback: FeedbackRequest):
    """
    Send feedback to a SharePoint list using the generated token.
    """
    client_id = os.getenv('JCR_API_CLIENT_ID')
    client_secret = secret_client.get_secret('jcr-client-secret').value
    spo_url = os.getenv('JCR_SPO_URL')

    client_credentials = ClientCredential(client_id, client_secret)
    ctx = ClientContext(spo_url).with_credentials(client_credentials)
    web = ctx.web.get().execute_query()

    # Access the SharePoint list
    list_title = "JCR-ChatBot-Feedbacks"
    target_list = ctx.web.lists.get_by_title(list_title)

    if feedback.is_disliked:
        # Create a new list item
        item_creation_info = {
            "Title": feedback.dislikeinfo.get("content", f"Feedback for message {feedback.message_id}"),
            "FeedbackDescription": feedback.dislikeinfo.get("feedbackForDislike", "No description provided"),
            "PersonName2": feedback.dislikeinfo.get("name", "No name provided"),  
            "PersonEmailId2": feedback.dislikeinfo.get("email", "No email-id provided")
        }
    if feedback.is_email:
        # Create a new list item
        item_creation_info = {
            "Title": feedback.emailInfo.get("title", f"Get Help from JCR Team"),
            "FeedbackDescription": feedback.emailInfo.get("emailContent", "No email content provided"),
            "PersonName2": feedback.emailInfo.get("name", "No name provided"),  
            "PersonEmailId2": feedback.emailInfo.get("email", "No email-id provided")
        }        
    new_item = target_list.add_item(item_creation_info).execute_query()

    logger.info(f"Feedback sent to SharePoint for message {feedback.message_id}")
    return new_item.properties['ID']
