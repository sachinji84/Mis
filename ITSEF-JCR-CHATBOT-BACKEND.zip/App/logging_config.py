import logging
from opencensus.ext.azure.log_exporter import AzureLogHandler
import os

def setup_application_insights_logger():
    # Set up Azure Application Insights logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Replace with your Azure Application Insights Instrumentation Key
    instrumentation_key = os.getenv("APPINSIGHTS_INSTRUMENTATIONKEY")
    if instrumentation_key:
        logger.addHandler(AzureLogHandler(connection_string=f'InstrumentationKey={instrumentation_key}'))

    return logger
