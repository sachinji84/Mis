paylaod  = {"asa_literatue":[
    {
        "section": "Introduction and Summary",
        "messages": [
            {
                "content": "Based on the comprehensive analysis of the provided uploaded_documents_content [ uploaded_documents_content ], craft an Introduction and Motivation section that accomplishes the following objectives: a. Begin by setting the stage for the reader, highlighting the significance and the broader context of the problem at hand. Elaborate on why this problem is worth investigating, drawing on key insights and gaps identified in the literature review. b. Clearly and precisely define the research question that guides this study. Ensure that the question is directly linked to the motivations and gaps identified in the literature review, and articulate how addressing this question could contribute to the field.                                                                                        Please generate a response that is approximately 500 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Methods",
        "messages": [
            {
                "content": "Based on the uploaded_documents_content provided [ uploaded_documents_content ] generate a comprehensive 'Methods' section that includes the following components: a. Clearly outline the scope of the review, specifying the journals searched, keywords used, and whether the focus was on empirical or theoretical studies. b. Describe the methods of data collection employed, including whether forward or backward citation tracking was utilized. c. Explain the method used to narrow down the final sample of articles, detailing the selection criteria, any manual review processes, and other relevant procedures. d. List the study characteristics that were extracted and included in the review matrix, providing a clear overview of the data gathered from the selected articles. e. If a meta-analysis was conducted as part of the review, describe the methods used for this analysis, including statistical techniques and models. f. Provide a detailed description of the study sample, including the number of studies/articles reviewed and a summary of their characteristics or summary statistics. Ensure that each component is thoroughly addressed to facilitate a clear understanding of the methodology behind the literature review. Ensure the generated content is grammatically correct and comprehensive .                                                                                                                                                                                                                                                                                                            Please generate a response that is approximately 500 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Explanation of key findings/mechanisms in the literature",
        "messages": [
            {
                "content": "Based on the comprehensive uploaded_documents_content provided [ uploaded_documents_content ] generate a detailed section titled 'Explanation of Key Findings/Mechanisms in the Literature.' This section should:1. **Subgroup Analysis**: Begin by categorizing the studies into subgroups based on distinct study characteristics (e.g., methodology, population, geographic location). For each subgroup, provide a deeper analysis of the individual studies, highlighting how these characteristics influence the findings and interpretations.2. **Citation and Findings**: For each study mentioned, ensure to cite it appropriately and summarize its key findings. Highlight how these findings contribute to the overall understanding of the subject matter and any significant patterns or discrepancies observed across the studies.3. **Sub-Questions Exploration**: Identify and discuss the types of sub-questions that the literature addresses. Explain how these sub-questions help in dissecting the broader research question, and what answers or insights they provide.4. **Mechanisms Discussion**: Focus on the mechanisms underlying the key findings. Explain how these mechanisms are supported or theorized within the literature, and the role they play in the context of the broader research question.Ensure that the section is comprehensive, logically organized, and provides a clear synthesis of the literature's contributions to the field.    Please generate a response that is approximately 1000 to 1200 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Summary of the findings of the literature",
        "messages": [
            {
                "content": "Based on the uploaded_documents_content provided [ uploaded_documents_content ] generate a comprehensive 'Summary of the Findings of the Literature' section that includes the following elements: a. Present the results of any meta-analysis conducted, highlighting key outcomes and statistical significance. b. Summarize the range of estimates found in the literature for the key parameter of interest, detailing the minimum, maximum, and any notable outliers or trends. c. Analyze and attempt to reconcile any contradictory findings across the documents, providing insights into possible reasons for discrepancies. Conclude by drawing overall lessons from the literature, emphasizing consensus points and unresolved questions. Please generate a response that is approximately 1000 to 1200 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Conclusion",
        "messages": [
            {
                "content": "Based on the comprehensive analysis of the provided uploaded_documents_content [ uploaded_documents_content ] generate a detailed Conclusion section that encompasses the following critical aspects: a. Summarize the policy implications derived from the existing literature, highlighting how the findings can influence or shape current and future policy decisions. b. Identify and articulate the open questions or gaps in the literature, emphasizing areas that require further research or exploration to advance understanding in the field. Please generate a response that is approximately 500 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    }
],
"policy_notes":[
    {
        "section": "Abstract",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] at first and generate an Abstract section that succinctly summarizes the research questions, key findings, and quantitative results derived from the uploaded_documents_content provided.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Introduction",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] at first and write an Introduction section that spans two pages. Clearly articulate the objective of the policy paper, providing comprehensive background information relevant to a specific economic or social development issue. detail all the methodology employed in conducting the research, outline the research questions investigated, summarize the key findings obtained (including quantitative evidence), and discuss the policy implications derived from these findings. Conclude this section with actionable policy recommendations based on the research outcomes. Please generate a response that is approximately 1000-1200 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Motivation",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] and write a section named Motivation that spans half a page. Clearly articulate the significance and relevance of the policy note's topic within the current academic and practical contexts. Justify why researchers and policymakers should prioritize attention to this specific issue, highlighting any gaps in existing literature or pressing societal needs that the policy note aims to address.  ",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Research Questions",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] at first and write section named Research Questions that spans half a page. Clearly state 3-4 specific research questions that the policy note aims to address. Each question should be focused and clearly articulated, reflecting the core objectives of the research and guiding the subsequent analysis and discussion.  Please generate a response that is no longer than 500 words.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Contribution to literature ",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] and write a section named Contribution to Literature  that spans half a page. Explain the importance of the policy note and detail how it will contribute to the existing body of research. Highlight the unique aspects of the policy note that differentiate it from previous studies, and clarify how it addresses gaps or limitations in the current literature. Justify the need for this research by outlining its potential to advance understanding, influence policy, or provide new insights into the topic.  Please generate a response that is no longer than 500 words.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Current Status and Key Challenges",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] at first and write a section named Current Status and Key Challenges that spans two pages. Provide a detailed summary on the current status of the research topic, providing an overview of the existing knowledge and recent developments. Identify and elaborate on key challenges in terms of resources, policy gaps, and institutional capacity that impact the topic. Include relevant quantitative evidence to support your discussion, highlighting statistical data, trends, or empirical findings that illustrate these challenges. Ensure the section offers a comprehensive and well-supported analysis of the present state and obstacles facing the issue. Please generate a response that is approximately 1000 - 1200 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Analysis",
        "messages": [
            {
                "content": "\"Conduct a thorough analysis of the source documents [ uploaded_documents_content ] and write a detailed section named \"Analysis\" that spans 6 pages covering the following: 1. Global Evidence and Experience: Demonstrating the global evidence and experience on programs that could provide solutions to challenges including 1) established solutions; and 2) new thinking, recent literature, and cutting-edge solutions. 2. Methodology and Empirical Evidence: - Illustrate the methodology used in the research, including details on data sources, analytical techniques, and any relevant empirical evidence drawn from the uploaded_documents_content. 3. Key Determinants: - Analyze the key determinants of the policy issue, identifying factors that significantly influence the outcomes and effectiveness of different solutions. Your analysis should be based solely on the information and findings found within the source documents. Ensure the section is detailed, well-supported by evidence, and clearly structured to address these components comprehensively. \"  Please generate a response that is approximately 3000 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Main Findings ",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] at first and write a section named Main Findings that spans four pages. Elaborate on the key findings of the policy note, including detailed explanations and quantitative evidence for each finding. For every finding, include stylized facts that highlight significant patterns or trends. Ensure the section is well-organized, clearly presenting how each finding contributes to the understanding of the issue and is supported by relevant data. ",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Conclusion and Policy Implications",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] at first and write a section named Conclusion and Policy Implications that spans two pages. Provide a detailed summary on the key findings of the policy note and provide forward-looking recommendations for reform. Include specific suggestions for improving economic or social policies, and outline necessary reforms for the country or sector. Offer actionable steps for government, Bank leadership, and other stakeholders to enhance policy design, strengthen institutions, and build capacity. Ensure the section is clear, practical, and focused on how the findings can inform and guide future actions. Please generate a response that is approximately 1000 - 1200 words long.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Bibliography",
        "messages": [
            {
                "content": "Read all the source documents [ uploaded_documents_content ] and  list all the data sources used to generate the policy note. Do not provide any other information other than the data sources name used for the analysis.",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    }

],
"policy_notes_structured":[
    {
        "section": "Abstract",
        "messages": [
            {
                "content": "Objective: Generate a compelling Abstract for a policy note document exploring the topic: input_topic.\n\nTask: Craft an Abstract section that succinctly summarizes the research questions, key findings, and quantitative results derived from the uploaded_documents_content provided. (approximately 1 paragraph within 200 words)\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. If these are insufficient or further details are required, enhance the abstract with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Introduction",
        "messages": [
            {
                "content": "Objective: Generate a compelling Introduction for a document exploring the topic: input_topic.\n\nTask: Generate a comprehensive section titled 'I Introduction' (approximately 2 pages with 1000-1200 words) that encompasses the following critical aspects:\n\n1. Clearly articulate the objective of the policy paper, providing comprehensive background information relevant to a specific economic or social development issue.\n2. Detail all the methodology employed in conducting the research.\n3. Outline the research questions investigated, summarize the key findings obtained (including quantitative evidence).\n4. Discuss the policy implications derived from these findings.\n5. Conclude this section with actionable policy recommendations based on the research outcomes.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. If these are insufficient or further details are required, enhance the abstract text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Motivation",
        "messages": [
            {
                "content": "Objective: Generate a compelling Motivation for a document exploring the topic:input_topic.\n\nTask: Generate a section titled 'Section II: Motivation' (approximately half a page with 150-200 words) that includes the following aspects:\n\n1. Clearly articulate the significance and relevance of the policy note's topic within the current academic and practical contexts.\n2. Justify why researchers and policymakers should prioritize attention to this specific issue, highlighting any gaps in existing literature or pressing societal needs that the policy note aims to address.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. If these are insufficient or further details are required, enhance the abstract text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Research Questions",
        "messages": [
            {
                "content": "Objective: Generate a compelling Research Questions section for a document exploring the topic: input_topic.\n\nTask: Generate a detailed section titled 'Section III: Research Questions' (approximately half a page with 150-200 words). Ensure to clearly state 3-4 specific research questions that the policy note aims to address. Each question should be focused and clearly articulated, reflecting the core objectives of the research and guiding the subsequent analysis and discussion.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. If these are insufficient or further details are required, enhance the abstract text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Contribution to literature ",
        "messages": [
            {
                "content": "Objective: Generate a compelling Contribution to literature for a document exploring the topic: input_topic.\n\nTask: Generate a detailed section titled 'Section IV: Contribution to literature' (approximately half a page with 150-200 words) that includes the following aspects:\n\n1. Explain the importance of the policy note and detail how it will contribute to the existing body of research.\n2. Highlight the unique aspects of the policy note that differentiate it from previous studies, and clarify how it addresses gaps or limitations in the current literature.\n3. Justify the need for this research by outlining its potential to advance understanding, influence policy, or provide new insights into the topic.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. If these are insufficient or further details are required, enhance the abstract text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Current Status and Key Challenges",
        "messages": [
            {
                "content": "Objective: Generate a compelling Current Status and Key Challenges for a document exploring the topic: input_topic.\n\nTask: Generate a detailed section titled 'Section V: Current Status and Key Challenges' (approximately 2 pages within 1000-1200 words) that includes the following aspects:\n\n1. Provide a detailed summary on the current status of the research topic, providing an overview of the existing knowledge and recent developments.\n2. Identify and elaborate on key challenges in terms of resources, policy gaps, and institutional capacity that impact the topic.\n3. Include relevant quantitative evidence to support your discussion, highlighting statistical data, trends, or empirical findings that illustrate these challenges.\n4. Ensure the section offers a comprehensive and well-supported analysis of the present state and obstacles facing the issue.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. If these are insufficient or further details are required, enhance the abstract text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Analysis",
        "messages": [
            {
                "content": "Objective: Generate a compelling Analysis for a document exploring the topic: input_topic.\n\nTask: Generate a detailed section titled 'Section VI: Analysis' (approximately 6 pages within 3000 words) that includes the following aspects, and ensure the section is detailed, well-supported by evidence, and clearly structured to address these components comprehensively:\n\n1. Global Evidence and Experience: Demonstrating the global evidence and experience on programs that could provide solutions to challenges including 1) established solutions; and 2) new thinking, recent literature, and cutting-edge solutions.\n2. Methodology and Empirical Evidence: Illustrate the methodology used in the research, including details on data sources, analytical techniques, and any relevant empirical evidence drawn from the uploaded_documents_content.\n3. Key Determinants: Analyze the key determinants of the policy issue, identifying factors that significantly influence the outcomes and effectiveness of different solutions.\n\nEnsure the section is detailed, well-supported by evidence, and clearly structured to address these components comprehensively.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. And then enhance the abstract text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center ",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Main Findings ",
        "messages": [
            {
                "content": "Objective: Generate a compelling Main Findings for a document exploring the topic: input_topic.\n\nTask: Generate a detailed section titled 'Section VII: Main Findings' (approximately 4 pages within 2000-2500 words) that includes the following aspects. Ensure the section is well-organized, clearly presenting how each finding contributes to the understanding of the issue and is supported by relevant data:\n\n1. Elaborate on the key findings of the policy note, including detailed explanations and quantitative evidence for each finding.\n2. For every finding, include stylized facts that highlight significant patterns or trends.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. And then enhance the text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Conclusion and Policy Implications",
        "messages": [
            {
                "content": "Objective: Generate a compelling Conclusion and Policy Implications for a document exploring the topic: input_topic.\n\nTask: Generate a detailed section titled 'Section VIII: Conclusion and Policy Implications' (approximately 2 pages within 1000-1500 words) that includes the following aspects:\n\n1. Provide a detailed summary on the key findings of the policy note and provide forward-looking recommendations for reform.\n2. Include specific suggestions for improving economic or social policies, and outline necessary reforms for the country or sector.\n3. Offer actionable steps for government, Bank leadership, and other stakeholders to enhance policy design, strengthen institutions, and build capacity.\n4. Ensure the section is clear, practical, and focused on how the findings can inform and guide future actions.\n\nPriority Sources:\n\nWhen generating the text, prioritize using information from the provided uploaded_documents_content. And then enhance the text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    },
    {
        "section": "Bibliography",
        "messages": [
            {
                "content": "Objective: Generate a list of all data sources used for generating a policy note document exploring the topic: input_topic.\n\nTask: List all the data sources used to generate the policy note with URL to access those data sources. Do not provide any other information other than the data sources name used for the analysis.\n\nPriority Sources: When generating the text, prioritize using information from the provided uploaded_documents_content and all the policy note sections. And then enhance the text with insights from the below sources:\n\n- International Organizations: World Bank, International Monetary Fund (IMF), Asian Development Bank (ADB), Organization for Economic Co-operation and Development (OECD)\n- Universities: Oxford University, London School of Economics, Cambridge University, Harvard University, Massachusetts Institute of Technology, Stanford University\n- Think Tanks: Brookings Institution, Atlantic Council, Wilson Center",
                "role": "system"
            },
            {
                "content": " Capital Budget Spending Efficiency and Impact on Economic Growth",
                "role": "user"
            }
        ],
        "max_tokens": 1024,
        "temp": 0,
        "timeout": 30,
        "top_p": 0.0
    }

]}