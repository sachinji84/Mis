from fastapi import APIRouter
from api.content_generation.router import router as content_generation_router 


router = APIRouter(
    prefix="",
    tags=[""],
    responses={404: {"description": "Not found"}}
)

router.include_router(content_generation_router)