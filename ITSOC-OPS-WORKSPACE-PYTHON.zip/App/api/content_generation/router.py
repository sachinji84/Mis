from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import json
import os
import time
from typing import List, OrderedDict
import uuid

import zipfile
from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
import requests
from integrations.azure_helper import downloadBlobFromContainer
from api.content_generation.content_gen_service import  generate_summary, read_chunk_file
from integrations.json_to_document import generate_documentfromresp
import logging
from azure.core.exceptions import HttpResponseError
from io import BytesIO

router = APIRouter(
    prefix="/contentgen",
    tags=["GenAI"],
    responses={404: {"description": "Not found"}}
)

@router.post("/generatesummary")
async def generatesummary(file: List[UploadFile]= File(None),topic: str = None,key: str = None): 
    logging.info("Entering generatesummary") 
    
    try:       
        logging.info("Befor API call") 
        if not file or len(file) == 0:
            resp=''
        else:
            resp=await read_chunk_file(file)
        unique_folder_name = str(uuid.uuid4())+time.strftime("%Y%m%d-%H%M%S")
        output=generate_summary(resp,topic,key)
        
        file_name = generate_documentfromresp(output["data"],topic,key,unique_folder_name)
        output["document_path"] = unique_folder_name+"/output/"+file_name
        # eval_file_name = get_eval_score(output)
        file_path = os.path.join(os.getcwd(),file_name)
        if os.path.exists(file_path):
            logging.error("Word file is successfully downloaded")
            response = JSONResponse(output,media_type='application/json')
            # FileResponse(path=file_path, filename=file_name, media_type='application/msword')
            response.headers["Content-Disposition"] = f"attachment; filename={file_name}"
            
            return response
       
    except HttpResponseError  as error1:
        if error1.error is not None:
            logging.error(f"error in notestotext: {error1.error}")
            if error1.error.code == "InvalidImage":
                logging.error(f"Received an invalid image error: {error1.error}")
            if error1.error.code == "InvalidRequest":
                logging.error(f"Received an invalid request error: {error1.error}")
            raise
        if "Invalid request".casefold() in error1.message.casefold():
            logging.error(f"Uh-oh! Seems there was an invalid request: {error1}")
        
    return JSONResponse(content={"status": "Failed", "data":" "})


@router.post("/downloadsummary")
async def generatesummary(file_path: str = None): 
    logging.info("Entering downloadsummary") 
    
    try:       
        logging.info("Befor API call") 
        stream ,filename = downloadBlobFromContainer("asa-literature-policy-notes",file_path)
        
        # file_path = os.path.join(os.getcwd(), filename)
        if stream.getbuffer().nbytes == 0:
            raise HTTPException(status_code=404, detail="Blob content is empty")
        # Write the stream to a temporary file
        # with open(file_path, "wb") as file:
        #     file_content = stream.read()
        #     logging.info(f"Writing {len(file_content)} bytes to {file_path}")
        #     file.write(file_content)
        return StreamingResponse(stream, media_type="application/octet-stream", headers={"Content-Disposition": f"attachment; filename={filename}"})
        # resposne.headers["Content-Disposition"] = f"attachment; filename={filename}"
        return resposne       
    except HttpResponseError  as error1:
        if error1.error is not None:
            logging.error(f"error in notestotext: {error1.error}")
            if error1.error.code == "InvalidImage":
                logging.error(f"Received an invalid image error: {error1.error}")
            if error1.error.code == "InvalidRequest":
                logging.error(f"Received an invalid request error: {error1.error}")
            raise
        if "Invalid request".casefold() in error1.message.casefold():
            logging.error(f"Uh-oh! Seems there was an invalid request: {error1}")
        
    return JSONResponse(content={"status": "Failed", "data":" "})





    
