from sqlalchemy import  Column, Integer, String, Text, TIMESTAMP, create_engine, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

from integrations.get_config import get_env_value


def init_postgres_db():
    DATABASE_URL = get_env_value("POSTGRES-DATABASE-URL")
    
    # Create an engine with connection pooling
    engine = create_engine(
        DATABASE_URL,
        pool_size=10,          # The size of the pool to be maintained
        max_overflow=20,       # The maximum number of connections to allow in connection pool "overflow"
        pool_timeout=30,       # The number of seconds to wait before giving up on getting a connection from the pool
        pool_recycle=1800      # The number of seconds a connection can persist before being recycled
    )
    
    # Create a configured "Session" class
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    
    return SessionLocal

