
import json
import os
from typing import OrderedDict
from api.content_generation.db_config import init_postgres_db
from integrations.get_config import get_env_value
from config import payload
from integrations.token_helper import TokenHelper
from integrations.http_util import multi_async_http_calls
from integrations.azure_helper import uploadBlobToContainer
# ,loaddocuments
# from integrations.documents_helper import chunkdocuments  
# from integrations.token_helper import TokenHelper  
import logging
from dotenv import load_dotenv
from sqlalchemy.orm import Session
from sqlalchemy.sql import text
load_dotenv()

async def read_chunk_file(upload_files,unique_folder_name):
    data = []
  
    if upload_files is not None and len(upload_files) > 0:
            for upload_file in upload_files:
                with open(os.getcwd()+"/"+upload_file.filename, "wb") as f:
                    f.write(upload_file.file.read())

                uploadBlobToContainer(os.getcwd()+"/"+upload_file.filename, unique_folder_name+"/"+upload_file.filename,"asa-literature-policy-notes")
    else:
            logging.info("No files to process")
    documents =""
    # loaddocuments("asa-literature-policy-notes",unique_folder_name) 
    # joined_text = chunkdocuments(documents)  
    return ""
    # return joined_text
def generate_summary(data1,topic,key):
            # data= load_json("payload.json",key)
            data =  getPayoads(key)
            for i in data:
                messages = [{"role":"user","content":i["prompt"].format(topic=topic)}]
                i["messages"]=messages
                i["max_tokens"]=get_env_value("max_tokens")
                i["temp"]=get_env_value("temp")
                i["timeout"]=get_env_value("timeout")
                i["top_p"]=get_env_value("top_p")
                # i["messages"][0]["content"].replace("uploaded_documents_content",data1).replace("input_topic",topic)
                #  i["messages"][0]["content"]=i["messages"][0]["content"].replace("uploaded_documents_content",data1)
            
            # headers = {"Ocp-Apim-Subscription-Key": "",
            #        "Authorization": "Bearer "+TokenHelper.get_access_token_ops_workspace(os.getenv("MAI_SCOPE")),
            #        "Content-Type": "application/json"}
            # api_url =os.getenv("MAI_COMPLETIONS_URL")
            # "https://opssearchapimqa.worldbank.org/conversationalai/openai/completions"
           
            results = multi_async_http_calls("", data, "")
            
            return Order_response(results,data)

    
def Order_response(results: dict,payloads) -> dict:
    orderd_keys = []
    ordered_results = OrderedDict()
    for payload in payloads:
        section = payload["section_name"]
        if section in results:
            ordered_results[section] = results[section]
            orderd_keys.append(section)
        else:
            logging.error(f"Section {section} not found in results")        
        ordered_results[section] = results[section]
    return {"sections":orderd_keys,"data":ordered_results}

def getPayoads(name):
    SessionLocal = init_postgres_db()
    db: Session = SessionLocal()
    try:
        query = text("SELECT * from opswrkspc.prompts where name=:name order by sequence asc")
        result = db.execute(query, {"name": name})
        rows = result.fetchall()
        keys = result.keys()
        data = [dict(zip(keys, row)) for row in rows]
    finally:
        db.close()
    return data

