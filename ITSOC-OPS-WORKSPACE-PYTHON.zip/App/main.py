from fastapi import FastAPI, HTTPException, status, Query, UploadFile, File
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.requests import Request
from pydantic import BaseModel
from msal import ConfidentialClientApplication
from azure.core.exceptions import HttpResponseError
# import fitz
from typing import List
from fastapi.responses import FileResponse
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '../App'))
from datetime import datetime
import encryptdecrypt
#import openai
#import pan das as pd
import time
import json
from langchain_community.document_loaders import AzureBlobStorageContainerLoader
import boto3
from requests_aws4auth import AWS4Auth
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import OpenSearchVectorSearch
from opensearchpy import  RequestsHttpConnection
from customEmbeddings import CustomEmbeddings
from langchain_community.embeddings.openai import OpenAIEmbeddings
import requests
import logging
from fpdf import FPDF
from dotenv import load_dotenv
import base64
from azuredocintelligence import *
import shutil
import mimetypes
from keyvault import *
from main_router import *
from docxtpl import DocxTemplate
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai import AzureOpenAI
import datetime
from chat_history import router as chat_history_router

load_dotenv()
logging.error("in main.py")
getSecrets()
description = """
Sample app to demonstrate file upload and download with FastAPI
"""
app = FastAPI(title="FileUploadAndDownloadApp",
              description=description,
              version="0.1")
app.include_router(router)
app.include_router(chat_history_router, prefix="/chat_history", tags=["Chat History"])
class HealthCheck(BaseModel):
    """Response model to validate and return when performing a health check."""

    status: str = "OK"
now = datetime.datetime.now()
date_time = now.strftime("%m_%d_%Y, %H_%M_%S_%p")

# @app.post("/upload/")
# async def highlight_words(file: UploadFile = File(...), words: List[str]= Query(None)):
#     path = os.getcwd()
#     file_path = os.path.join(path,"words_highlight "+date_time+".pdf")
#     if os.path.exists(file_path):
#         os.remove(file_path)
#     pdf_file = fitz.open(file.filename)
#     words_dict={}
#     words_count = {}
#     words_count_dict = {}
#     for page in pdf_file:
#         for i in words:
#             text_to_be_highlighted = i
#             highlight = page.search_for(text_to_be_highlighted)
#             if len(highlight) !=0:
#                 page_str = int(str(page).replace(" of "+file.filename,"").replace("page ",""))+1
#                 if text_to_be_highlighted in words_dict:
#                     words_count[text_to_be_highlighted] += len(highlight)
#                     words_dict[text_to_be_highlighted].append(page_str)
#                     words_count_dict[text_to_be_highlighted] = {'Count':words_count[text_to_be_highlighted],'PageNo': words_dict[text_to_be_highlighted]}
#                 else:
#                     words_count[text_to_be_highlighted] = len(highlight)
#                     words_dict.update({text_to_be_highlighted: [page_str]})
#                     words_count_dict[text_to_be_highlighted] = {'Count':words_count[text_to_be_highlighted],'PageNo': words_dict[text_to_be_highlighted]}
#                 for inst in highlight:
#                     highlight = page.add_highlight_annot(inst)

#                     highlight.update()
                    
#     return words_count_dict

@app.get(
    "/health",
    tags=["healthcheck"],
    summary="Perform a Health Check",
    response_description="Return HTTP Status Code 200 (OK)",
    status_code=status.HTTP_200_OK,
    response_model=HealthCheck,
)
def get_health() -> HealthCheck:
    """
    ## Perform a Health Check
    Endpoint to perform a healthcheck on. This endpoint can primarily be used Docker
    to ensure a robust container orchestration and management is in place. Other
    services which rely on proper functioning of the API service will not deploy if this
    endpoint returns any other HTTP status code except 200 (OK).
    Returns:
        HealthCheck: Returns a JSON response with the health status
    """
    return HealthCheck(status="OK")
# @app.post("/download/")
# async def download_file(file: UploadFile = File(...), words: List[str]= Query(None)):
#     pdf_file = fitz.open(file.filename)
#     for page in pdf_file:
#         for i in words:
#             text_to_be_highlighted = i
#             highlight = page.search_for(text_to_be_highlighted)
#             for inst in highlight:
#                 highlight = page.add_highlight_annot(inst)

#                 highlight.update()
                    
#     pdf_file.save("words_highlight "+date_time+".pdf", garbage=4, deflate=True, clean=True)
#     path = os.getcwd()
#     file_path = os.path.join(path,"words_highlight "+date_time+".pdf")
#     if os.path.exists(file_path):
#        return FileResponse(path=file_path, filename=file_path, media_type='application/pdf')
#     else:
#         return {"message": "File not found"}

    
@app.post("/docstring/")
async def search_string(input : str,country : str = None):
    remove_file("MAL")
    aws_access_key_id =  decrypt(os.getenv("AWS-ACCESS-KEY"))
    aws_secret_access_key = decrypt(os.getenv("AWS-SECRET-ACCESS-KEY"))
    region = 'us-east-1'
    service = os.getenv("OPS_OPEN_SEARCH_SERVICE")
    credentials = boto3.Session(
    aws_access_key_id, aws_secret_access_key).get_credentials()
    awsauth = AWS4Auth(aws_access_key_id, aws_secret_access_key,
                       region, service, session_token=credentials.token)
    docsearch = OpenSearchVectorSearch(
        index_name=os.getenv("OPEN_SEARCH_INDEX_NAME"),
        http_auth=awsauth,
        embedding_function=CustomEmbeddings,
        timeout=300,
        opensearch_url=os.getenv("OPEN_SEARCH_URL"),
        connection_class=RequestsHttpConnection,   
        engine="faiss"
        )
    query = "can you get mission letter for nepal"
    logging.error(input)
    logging.error(country)
    if country !=None:
        logging.error("*******140*********")
        docs10 = docsearch.similarity_search(query, k=10 ,search_type="script_scoring",
                                                  pre_filter={"match": {"metadata.country": country}})
        pagecontent = ' '.join([i.page_content for i in docs10])
        logging.error('*****************************************************************')
        logging.error(pagecontent)
        logging.error('*****************************************************************')
        app = ConfidentialClientApplication(
            client_id=os.getenv("CLIENT_ID"),
            authority=os.getenv("AUTHORITY"),
            client_credential=decrypt(os.getenv("CLIENT_SECRET"))
            )
        SCOPE = [os.getenv("SCOPE")]
        result = app.acquire_token_silent(SCOPE, account=None)
        if not result:
            result = app.acquire_token_for_client(scopes=SCOPE)
        access_token = result['access_token']
        headers = {"Ocp-Apim-Subscription-Key": os.getenv("OCP_APIM_SUBSCRIPTION_KEY"),
                "Authorization": "Bearer "+access_token,
                }
        api_url = os.getenv("MAI_COMPLETIONS_URL")
        completionspayload = {"messages": [{"content": "prasanna is an actor","role": "system"},
                                        {"content": input,"role": "user"}],"max_tokens": 1024,"temp": 0,"timeout": 30,"top_p": 0.0}
        prompt = f"Generate a mission letter based on the following:\n{pagecontent}"
        completionspayload["messages"][0]["content"] = prompt
        completionspayload["messages"][1]["content"] = "Please generate a mission letter using the sample letters in context :Mission Name - Digital Nepal Acceleration (DNA) Project (IDA Credit No. 7144-NP) Fourth Implementation Review And Restructuring Consultation Country - Nepal \n Objective - the primary objective of the consultation is to urgently discuss steps to support implementation of relevant activities, and to initiate the restructuring of the Project. In addition, the team will engage with the private sector stakeholders to identify approaches to mobilize private capital to support broadband rollout in rural areas. The consultation will include engagement with Ministry of Finance, Ministry of Communications & IT and its agencies, Nepal Telecommunications Authority, and private sector stakeholders.Start date - Dec 12, 2023End date - Dec 14, 2023"
        response = requests.post(api_url , json=completionspayload,headers=headers)
        
        # save FPDF() class into a 
        # variable pdf
        pdf = FPDF()
        # Add a page
        pdf.add_page()
                
        # set style and size of font 
        # that you want in the pdf
        pdf.set_font("Arial", size = 15)
                
        # create a cell
        pdf.multi_cell(200, 10, txt = response.text,align = 'C')

        # save the pdf with name .pdf
        pdf.output("MAL"+" "+date_time+".pdf")
        path = os.getcwd()
        file_path = os.path.join(path,"MAL "+date_time+".pdf")
        if os.path.exists(file_path):
            logging.error("PDF file is successfully downloaded")
            return FileResponse(path=file_path, filename=file_path, media_type='application/pdf')
        else:
            logging.info("PDF file is not found")
            return {"message": "File not found"}
    else:
        logging.error("*******145*********")
        docs10 = docsearch.similarity_search(query,
                                         k=10
                                         )
    pagecontent = ' '.join([i.page_content for i in docs10])
    logging.error('*****************************************************************')
    logging.error(pagecontent)
    logging.error('*****************************************************************')

    app = ConfidentialClientApplication(
        client_id=os.getenv("CLIENT_ID"),
        authority=os.getenv("AUTHORITY"),
        client_credential=decrypt(os.getenv("CLIENT-SECRET"))
        )
    SCOPE = [os.getenv("SCOPE")]
    result = app.acquire_token_silent(SCOPE, account=None)
    if not result:
        result = app.acquire_token_for_client(scopes=SCOPE)
    access_token = result['access_token']
    headers = {"Ocp-Apim-Subscription-Key": os.getenv("OCP_APIM_SUBSCRIPTION_KEY"),
               "Authorization": "Bearer "+access_token,
               "Content-Type": "application/json"}
    api_url = os.getenv("MAI_COMPLETIONS_URL")
    completionspayload = {"messages": [{"content": "","role": "system"},
                                           {"content": input,"role": "user"}],"max_tokens": 1024,"temp": 0,"timeout": 30,"top_p": 0.0}
    prompt = f"Generate a mission letter based on the following:\n{input}"
    completionspayload["messages"][0]["content"] = pagecontent
    # prompt
    # completionspayload["messages"][1]["content"] = "Please generate a mission letter using the sample letters in context :Mission Name - Digital Nepal Acceleration (DNA) Project (IDA Credit No. 7144-NP) Fourth Implementation Review And Restructuring Consultation Country - Nepal \n Objective - the primary objective of the consultation is to urgently discuss steps to support implementation of relevant activities, and to initiate the restructuring of the Project. In addition, the team will engage with the private sector stakeholders to identify approaches to mobilize private capital to support broadband rollout in rural areas. The consultation will include engagement with Ministry of Finance, Ministry of Communications & IT and its agencies, Nepal Telecommunications Authority, and private sector stakeholders.Start date - Dec 12, 2023End date - Dec 14, 2023"
    response = requests.post(api_url , json=completionspayload,headers=headers)
    pdf = FPDF()
        # Add a page
    pdf.add_page()
                
        # set style and size of font 
        # that you want in the pdf
    pdf.set_font("Arial", size = 15)
                
        # create a cell
    pdf.multi_cell(200, 10, txt = response.text,align = 'C')    
    # create a cell

    # save the pdf with name .pdf
   # pdf.output("string_to_Pdffrmservice.pdf") 
    
    # Send pdf as base64 bytestring
    pdf_string = pdf.output(dest='S')
    pdf_bytes  = pdf_string.encode('utf-8')

    base64_bytes  = base64.b64encode(pdf_bytes)
    base64_string = base64_bytes.decode('utf-8')

   # print(base64_string)
 

        # save the pdf with name .pdf
    pdf.output("MAL"+" "+date_time+".pdf")
    path = os.getcwd()
    file_path = os.path.join(path,"MAL "+date_time+".pdf")
    if os.path.exists(file_path):
        logging.error("PDF file is successfully downloaded")
        return FileResponse(path=file_path, filename=file_path, media_type='application/pdf')
    else:
        logging.info("PDF file is not found")
        return {"message": "File not found"}

@app.get("/health2")
async def health_check(request: Request):
    deployed_timestamp = get_deployed_timestamp()
    current_time = get_current_time()
    return JSONResponse(content={"message": "Health check passed", "deployed_timestamp": deployed_timestamp, "current_time": current_time})
def get_deployed_timestamp():
    file_path = os.path.abspath(__file__)
    timestamp = os.path.getmtime(file_path)
    return datetime.datetime.fromtimestamp(timestamp).isoformat()

def get_current_time():
    return datetime.datetime.now().isoformat()

def remove_file(prefix):
    path = os.getcwd()
    files = os.listdir(path)

    for file_name in files:
        if file_name.startswith(prefix):
            file_path = os.path.join(path, file_name)
            try:
                os.remove(file_path)
                logging.info(f"Removed: {file_path}")
            except Exception as e:
                logging.error(f"Error removing {file_path}: {e}")


@app.post("/notestotext")
async def notestotext(file: List[UploadFile]= File(None),desc: str = None): 
    logging.info("Entering notestotext") 
    try:       
        logging.error("Befor API call") 
        resp=await api_call(file,desc)
        return JSONResponse(content={"status": "Success", "summary":resp})
    except HttpResponseError  as error1:
        if error1.error is not None:
            logging.error(f"error in notestotext: {error1.error}")
            if error1.error.code == "InvalidImage":
                logging.error(f"Received an invalid image error: {error1.error}")
            if error1.error.code == "InvalidRequest":
                logging.error(f"Received an invalid request error: {error1.error}")
            raise
        if "Invalid request".casefold() in error1.message.casefold():
            logging.error(f"Uh-oh! Seems there was an invalid request: {error1}")
        
    return JSONResponse(content={"status": "Failed", "data":" "})

@app.post("/downloadtotest")
async def downloadtotest(file: List[UploadFile]= File(None),desc: str = None): 
    logging.info("Entering downloadtotext") 
    try:       
        logging.error("Befor API call") 
        resp=await api_call(file,desc)
        template = DocxTemplate("Report_template.docx")
        # Render the template with the context data
        template.render(resp)
        # Save the generated document to a new file
        template.save("Report_Document"+" "+date_time+".docx")
        path = os.getcwd()
        file_path = os.path.join(path,"Report_Document "+date_time+".docx")
        if os.path.exists(file_path):
            logging.error("Word file is successfully downloaded")
            return FileResponse(path=file_path, filename=file_path, media_type='application/msword')   
        else:
            logging.info("Word file is not found")
            return {"message": "File not found"}

    except HttpResponseError  as error1:
        if error1.error is not None:
            logging.error(f"error in notestotext: {error1.error}")
            if error1.error.code == "InvalidImage":
                logging.error(f"Received an invalid image error: {error1.error}")
            if error1.error.code == "InvalidRequest":
                logging.error(f"Received an invalid request error: {error1.error}")
            raise
        if "Invalid request".casefold() in error1.message.casefold():
            logging.error(f"Uh-oh! Seems there was an invalid request: {error1}")
        
    return JSONResponse(content={"status": "Failed", "data":" "})

@app.post("/downloadfromjson")
async def downloadtotest(resp: dict): 
    logging.info("Entering downloadfromjson") 
    try:       
        logging.error("Befor API call") 
        remove_file("Report_Document")
        template = DocxTemplate("Report_Template.docx")
        # Render the template with the context data
        template.render(resp)
        # Save the generated document to a new file
        template.save("Report_Document"+" "+date_time+".docx")
        path = os.getcwd()
        file_path = os.path.join(path,"Report_Document "+date_time+".docx")
        if os.path.exists(file_path):
            logging.error("Word file is successfully downloaded")
            return FileResponse(path=file_path, filename=file_path, media_type='application/msword')   
        else:
            logging.info("Word file is not found")
            return {"message": "File not found"}

    except HttpResponseError  as error1:
        if error1.error is not None:
            logging.error(f"error in notestotext: {error1.error}")
            if error1.error.code == "InvalidImage":
                logging.error(f"Received an invalid image error: {error1.error}")
            if error1.error.code == "InvalidRequest":
                logging.error(f"Received an invalid request error: {error1.error}")
            raise
        if "Invalid request".casefold() in error1.message.casefold():
            logging.error(f"Uh-oh! Seems there was an invalid request: {error1}")
        
    return JSONResponse(content={"status": "Failed", "data":" "})

async def  api_call(upload_files,desc: str = None):
    """
    API call to perform some operation.
    """
    logging.error("in API call")
    app = ConfidentialClientApplication(
        client_id=os.getenv("CLIENT_ID"),
        authority=os.getenv("AUTHORITY"),
        client_credential=decrypt(os.getenv("CLIENT-SECRET"))
    )
   
    logging.error("after app initialization")
    scope = [os.getenv("SCOPE")]
    result = app.acquire_token_silent(scope, account=None)
    if not result:
        result = app.acquire_token_for_client(scopes=scope)
        logging.error(result)
        print(result)
        access_token = result['access_token']
        logging.error("got token")
        headers = {
            "Ocp-Apim-Subscription-Key": os.getenv("OCP_APIM_SUBSCRIPTION_KEY"),
            "Authorization": "Bearer " + access_token,
            # 'Content-type': 'multipart/form-data'
        }
        api_url = os.getenv("MAI_SUMMARY_URL1")
        payload = {'fileDes': desc}
        files =[]
        if upload_files is not None and len(upload_files) > 0:
            for upload_file in upload_files:
                filename = upload_file.filename
                mime_type = mimetypes.guess_type(filename)[0]
                content =await upload_file.read()
                files.append(('file', (filename, content, mime_type)))
        else:
            logging.info("No files to process")
        response = requests.post(api_url, headers=headers, files=files,data=payload,  timeout=120)
        logging.info("got response")
        logging.info(response)
    return response.text
    # logging.error(response)


class ChatRequest(BaseModel):
    messages: list
   

# from fastapi.middleware.cors import CORSMiddleware
# origins = [
#     "http://localhost:4200",  # Frontend origin
# ]

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=origins,  # Origins allowed to make requests
#     allow_credentials=True,  # Allow cookies to be included
#     allow_methods=["*"],  # HTTP methods allowed
#     allow_headers=["*"],  # Headers allowed
# ) 

@app.post("/chatapi", response_class=StreamingResponse, responses={200: {"description": "Streamed response"}})
async def send_request(request: ChatRequest):
    token_provider = get_bearer_token_provider(DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default")
    api_version = "2024-05-01-preview"

    client = AzureOpenAI(
        api_version=api_version,
        azure_endpoint=os.getenv("CHATBOT_AZURE_OPENAI_ENDPOINT"),
        azure_ad_token_provider=token_provider,
    )

    def generate_response():        
            completion = client.chat.completions.create(
                model=os.getenv("CHATBOT_OPEN_AI_DEPLOYMENT"),
                messages=request.messages,
                max_tokens=4000,
                temperature=0,
                top_p=0.95,
                frequency_penalty=0,
                presence_penalty=0,
                stop=None,
                extra_body={
                    "data_sources": [
                        {
                            "type": "azure_search",
                            "parameters": {
                                "endpoint": os.getenv("CHABOT_SEARCH_ENDPOINT"),
                                "index_name": os.getenv("CHATBOT_JCR_SEARCH_INDEX"),
                                "authentication": {
                                    "type": "system_assigned_managed_identity"
                                }
                            }
                        }
                    ]
                },
                stream=True,
            )
            logging.info("Completion created successfully")

            citations = []
            intent=[]
            for event in completion:
                if event.choices:  # Access `content` directly
                    if hasattr(event.choices[0].delta, "model_extra") and citations.__len__() == 0:
                        model_extra = event.choices[0].delta.model_extra
                        context = model_extra.get('context', {})
                        citations = context.get('citations', [])
                        intent = context.get('intent', [])
                    if event.choices[0].delta.content:
                        yield event.choices[0].delta.content 

            yield '<<>>'            
            yield json.dumps({"citations": citations, "intent": intent})

    try:
       return StreamingResponse(generate_response(), media_type="text/plain") 
    except Exception as e:
        logging.error(f"Error creating completion: {e}")


@app.post("/followupprompts")
async def followup_prompts(request: ChatRequest):
    token_provider = get_bearer_token_provider(DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default")
    api_version = "2024-05-01-preview"
   

    client = AzureOpenAI(
                api_version=api_version,
                azure_endpoint=os.getenv("CHATBOT_AZURE_OPENAI_ENDPOINT"),
                azure_ad_token_provider=token_provider,
            )

    completion = client.chat.completions.create(
        model=os.getenv("CHATBOT_OPEN_AI_DEPLOYMENT"),
        messages=request.messages,
        max_tokens=800,
        temperature=0,
        top_p=0.95,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None,
        extra_body={
            "data_sources": [
                {
                    "type": "azure_search",
                    "parameters": {
                        "endpoint": os.getenv("CHABOT_SEARCH_ENDPOINT"),
                        "index_name": os.getenv("CHATBOT_JCR_SEARCH_INDEX"),
                        "authentication": {
                            "type": "system_assigned_managed_identity"
                        }
                    }
                }
            ]
        },
        )
    logging.info("Completion created successfully")
    return completion.choices[0].message.content
