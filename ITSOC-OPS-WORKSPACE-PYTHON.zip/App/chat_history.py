from fastapi import APIRouter, HTTPException
from azure.search.documents import SearchClient
from azure.identity import DefaultAzureCredential
from dotenv import load_dotenv
import uuid
import datetime
import os

load_dotenv()
# Create a router for chat history endpoints
router = APIRouter()


@router.post("/message")
async def save_message(message_data: dict):
    """
    Save a chat message to Azure Search.
    """
    credential = DefaultAzureCredential()

    client = SearchClient(endpoint=os.environ.get("CHABOT_SEARCH_ENDPOINT"), index_name='chat_messages', credential=credential)
    try:
        result = client.upload_documents(documents=[message_data])
        return {"status": "success", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/session/{chatbot_name}/{session_id}/history")
async def fetch_messages(chatbot_name: str, session_id: str):
    """
    Fetch chat history for a given session and chatbot.
    """
    credential = DefaultAzureCredential()

    client = SearchClient(endpoint=os.environ.get("CHABOT_SEARCH_ENDPOINT"), index_name='chat_messages', credential=credential)
    try:
        results = client.search(
            search_text="",
            filter=f"session_id eq '{session_id}' and chatbot_name eq '{chatbot_name}'",
            order_by="timestamp asc"
        )
        return [result for result in results]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/user/{user_id}/sessions")
async def list_sessions(user_id: str):
    """
    List all chat sessions for a given user.
    """
    credential = DefaultAzureCredential()

    client = SearchClient(endpoint=os.environ.get("CHABOT_SEARCH_ENDPOINT"), index_name="chat_sessions", credential=credential)
    try:
        results = client.search(
            search_text="",
            filter=f"user_id eq '{user_id}'",
            order_by="created_at desc"
        )
        return [result for result in results]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/session")
async def create_session(user_id: str, chatbot_name: str, first_query: str):
    """
    Create a new chat session in the Azure Search index.
    """
    credential = DefaultAzureCredential()

    client = SearchClient(endpoint=os.environ.get("CHABOT_SEARCH_ENDPOINT"), index_name="chat_sessions", credential=credential)

    # Generate session_id and session_name
    session_id = str(uuid.uuid4())  # Unique session ID
    session_name = first_query[:30] # Use the first query (truncated) as the session name

    # Create session data
    session_data = {
        "session_id": session_id,
        "user_id": user_id,
        "chatbot_name": chatbot_name,
        "session_name": session_name,
        "created_at": datetime.datetime.now().isoformat() + "Z"
    }

    try:
        # Save session to Azure Search
        result = client.upload_documents(documents=[session_data])
        return {"status": "success", "session_id": session_id, "session_name": session_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
