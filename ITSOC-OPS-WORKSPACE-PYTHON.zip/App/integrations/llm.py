
# Import Azure OpenAI
from langchain_openai import AzureChatOpenAI
 

# Create an instance of Azure OpenAI
# Replace the deployment name with your own


def invoke(message):
    llm_instance = AzureChatOpenAI(
    deployment_name="gpt-4o",
    temperature=0
    )
    # Invoke the model
    try:
        response = llm_instance(message)
    except Exception as e:
        response = f"Error invoking model: {e}"
    return response