import os


def get_env_value(key_name):
    return os.getenv(key_name)