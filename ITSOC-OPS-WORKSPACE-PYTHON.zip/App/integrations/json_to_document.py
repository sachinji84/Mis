import datetime
import os

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH


from integrations.azure_helper import uploadBlobToContainer


def generate_documentfromresp(results,topic,key,unique_folder_name):
    now1 = datetime.datetime.now()
    date_time1 = now1.strftime("%m_%d_%Y-%H_%M_%S_%p")
    doc = Document()
    if key=="asa_literatue":
        doc.add_heading(f'Topic:{topic}', level=3)
    doc.add_heading('LITERATURE REVIEW' if key=="asa_literature" else "Policy Notes", level=1).paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for section, result in results.items():
        # doc.add_heading(section, level=2)
        # doc.add_paragraph(result)
        lines = result.split('\n', 1)        
        first_line = lines[0]
        if(len(first_line) > 80) :
            doc.add_heading(section, level=2)
            doc.add_paragraph(result)
        else :
            remaining_content = lines[1] if len(lines) > 1 else ""
        # Add the first line as a heading with color
            heading = doc.add_heading(first_line,level=2)
            if remaining_content:
                doc.add_paragraph(remaining_content)
        
    file_name = f"{key}{date_time1}.docx"
    file_path = os.path.join(os.getcwd(), file_name)
    doc.save(file_name)
    uploadBlobToContainer(file_path, f"{unique_folder_name}/output/{file_name}","asa-literature-policy-notes")
    return file_name