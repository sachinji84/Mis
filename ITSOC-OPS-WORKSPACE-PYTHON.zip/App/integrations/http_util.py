

from concurrent.futures import ThreadPoolExecutor, as_completed
import re
from typing import OrderedDict
from integrations import llm

import logging
import requests


def multi_async_http_calls(api_url, inputRequestPayloads, headers):
    api_url =api_url
    # "https://opssearchapimqa.worldbank.org/conversationalai/openai/completions"
    payloads =  OrderedDict((i, payload) for i, payload in enumerate(inputRequestPayloads))
    results = OrderedDict()
    with ThreadPoolExecutor(max_workers=len(payloads)) as executor:
        future_to_api = {executor.submit(call_llm, api_url, payloads[i], headers): (i,payload )for (i, payload) in  payloads.items()}
        for future in as_completed(future_to_api):
            index, payload = future_to_api[future]
            section = payload["section_name"]
            try:
                result = future.result()
                result = re.sub(r'#+|[*]{2}', '', result)
                results[section] = result
            except Exception as e:
                logging.error(f"API call to {api_url} failed: {e}")
    return results

def call_api(api_url, payload, headers):
    try:
        response = requests.post(api_url, json=payload, headers=headers)
        print(response)
    except Exception as e:
        logging.error(f"API call to {api_url} failed: {e}")
        return None
           
    return  response.text 
def call_llm(api_url, payload, headers):
    try:
        response = llm.invoke(payload["messages"])
        print(response)
    except Exception as e:
        logging.error(f"API call to {api_url} failed: {e}")
        return None
           
    return  response.content 