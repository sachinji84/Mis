import os
import io
from datetime import datetime
from urllib import parse
# from logging_functions.app_insights import logging
import logging

from fastapi import  HTTPException
from typing import List, Tuple
# from pydantic import BaseModel

# from azure.search.documents import SearchClient
# from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient,  BlobClient
# from azure.core.credentials import AzureKeyCredential
# from models.common_models import DocMetadataModel, ExtractTextModel
from langchain_community.document_loaders import AzureBlobStorageContainerLoader

from util.encryptdecrypt import decrypt



def get_blob_from_url(blob_url,container_name='data/document-mop/raw'):
    try:
        if os.getenv('isLocalDevelopment'):
            blob_service_client = BlobServiceClient.from_connection_string(conn_str=os.getenv('AzureWebJobsStorage'))
            parts = blob_url.split("/")
            blob_name = parts[-1]
            blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
        else:
            blob_client = BlobClient.from_blob_url(blob_url,credential=DefaultAzureCredential())
            blob_data = blob_client.download_blob().readall()
        blob_data = blob_client.download_blob().readall()
        return blob_data
    except Exception as ex:
            logging.info(f"Error reading blob: {ex}")
            raise HTTPException(status_code=500, detail= {'error': str(ex)})

def uploadBlobToContainer(newFile,blobName,containerName):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(conn_str=os.getenv('AzureWebJobsStorage'))
        # token_credential = DefaultAzureCredential()
        # blob_service_client = blob_service_client = BlobServiceClient(account_url=os.getenv("BLOB_ACCOUNT_URL"),credential=token_credential)
        blob_client = blob_service_client.get_blob_client(container=containerName, blob = blobName)
        # container_client = blob_service_client.get_container_client(containerName)
        # blob_client.upload_blob(newFile,overwrite=True)
        container_client = blob_service_client.get_container_client(containerName)
        with open(newFile, "rb") as data:
            container_client.upload_blob(name=blobName, data=data, overwrite=True)
        print(f'uploaded {newFile}')
        return blob_client.url
    except Exception as e:
        logging.info(f'uploadBlobToContainer Exception -> {e}')

def downloadBlobFromContainer(container_name,blob_name):
    try:
        container_client = get_container_client(container_name)
        # blob_service_client = blob_service_client = BlobServiceClient.from_connection_string(conn_str=os.getenv('AzureWebJobsStorage'))
        # blob_client = blob_service_client.get_blob_client(container=containerName, blob = blobName)
        blob_client = container_client.get_blob_client(blob_name)
       # Download the blob to a stream
        stream = io.BytesIO()
        download_stream = blob_client.download_blob()
        download_stream.readinto(stream)
        filename = os.path.basename(blob_client.url)
        # Move the cursor to the beginning of the stream
        stream.seek(0)       
        return stream,filename
    except Exception as e:
        logging.info(f'downloadBlobFromContainer Exception -> {e}')
        raise Exception(e)

def upload_file(container_name: str, file_name: str, data, folder_path: str = None, doc_id: str = None) -> Tuple[bool, str]:
    output = (False, "")
    try:
        container_client = get_container_client(container_name)
        
        if folder_path:
            file_name = f"{folder_path}/{file_name}"
        
        blob_client = container_client.get_blob_client(file_name)
        
        metadata = {}
        if doc_id:
            # Add custom metadata properties
            metadata["document_id"] = doc_id

        exists = blob_client.exists()
        if exists:
            new_file_name = f"{os.path.splitext(file_name)[0]}_{datetime.now().strftime('%Y%m%d%H%M%S%f')}{os.path.splitext(file_name)[1]}"
            if folder_path:
                new_file_name = f"{folder_path}/{os.path.basename(new_file_name)}"
            
            blob_client_new = container_client.get_blob_client(new_file_name)
            blob_client_new.upload_blob(data)
            
            if doc_id:
                blob_client_new.set_blob_metadata(metadata)

            file_url = parse.unquote(blob_client_new.url)
        else:
            blob_client.upload_blob(data)
            
            if doc_id:
                blob_client.set_blob_metadata(metadata)

            file_url = parse.unquote(blob_client.url)

        output = (True, file_url)
    except Exception as ex:
        output = (False, str(ex))
    return output

def get_container_client(container_name: str) -> BlobServiceClient:   
    container_client = None
    if os.getenv("isLocalDevelopment"):
        connection_string = decrypt(os.getenv('BLOB-CONNECTION-STR'))
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        container_client = blob_service_client.get_container_client(container_name)
    else:
        account_name = os.getenv("BlobAccountName")        
        blob_service_client = BlobServiceClient(f"https://{account_name}.blob.core.windows.net/",credential=DefaultAzureCredential())
        container_client = blob_service_client.get_container_client(container_name)

    return container_client


# def merge_or_upload(index_name : str, doc_metadata: DocMetadataModel):
#     obj_return = (False, "", "")
#     try:
#         service_endpoint = os.getenv("SearchServiceUrl")
#         # index_name = os.getenv["AZURE_SEARCH_INDEX_NAME"]
#         key = os.getenv("AzureOpsSearchApiKey")
#         # batch = IndexDocumentsBatch()
#         # batch.add_merge_or_upload_actions(obj)
#         collection = [
#             {
#                 "document_id": doc_metadata.document_id,
#                 "package_id": doc_metadata.package_id,
#                 "app_id": doc_metadata.app_id,
#                 "document_name": doc_metadata.document_name,
#                 "document_status": doc_metadata.document_status,
#                 "document_orig_ext": doc_metadata.document_orig_ext,
#                 "total_filecount": doc_metadata.total_filecount,
#                 "document_type": doc_metadata.document_type,
#                 "requested_by": doc_metadata.requested_by,
#                 "upload_mode": doc_metadata.upload_mode,
#                 "project_id": doc_metadata.project_id,
#                 "project_info": doc_metadata.project_info,
#                 "isactive": doc_metadata.isactive,
#                 "created_date": doc_metadata.created_date,
#                 "created_by": doc_metadata.created_by,
#                 "modified_date": doc_metadata.modified_date,
#                 "modified_by": doc_metadata.modified_by
#             }
#         ]

#         search_client = SearchClient(service_endpoint, index_name, AzureKeyCredential(key))
        
#         results = search_client.merge_or_upload_documents(collection)
#         obj_return = (True, str(results[0].status_code), '')
#     except Exception as e:
#         print(str(e))
#         logging.info(f"azureSearch Exception occured -> {e}")
#         obj_return = (False, '', str(e))
#     return obj_return

# def search_query(index_name, filterqry, select_fields, page, page_size):
#     obj_return = (False, '', '')
#     try:
#         service_endpoint = os.getenv("SearchServiceUrl")
#         key = os.getenv("AzureOpsSearchApiKey")

#         search_client = SearchClient(service_endpoint, index_name, AzureKeyCredential(key))
#         response = search_client.search(search_text="*",include_total_count=True,filter=filterqry,select=select_fields)
#         search_results = []
#         for item in response:
#             search_results.append(item)
#         obj_return = (True, search_results, '')
#     except Exception as ex:
#         obj_return = (False, '', str(ex))
#         logging.info(f"azureSearch Exception occured -> {ex}")
#     return obj_return



class DocIntelligenceHelper:

    # @staticmethod
    # async def doc_int_file_text(files: List[UploadFile]) -> List[ExtractTextModel]:
    #     extracted_text_lst = []
    #     for item in files:
    #         content = await item.read()
    #         stream = io.BytesIO(content)
    #         stream.seek(0)
    #         result = DocIntelligenceHelper.doc_int_kw_from_img(stream)
    #         extracted_text_obj = ExtractTextModel(
    #             fileName=item.filename,
    #             extractedWords=result[1] if result[0] else result[2]
    #         )
    #         extracted_text_lst.append(extracted_text_obj)
    #     return extracted_text_lst

    # @staticmethod
    # def doc_int_kw_from_img(img_stream: io.BytesIO) -> Tuple[bool, str, str]:
    #     try:
    #         endpoint = os.getenv("DocIntellegenceEndPoint")
    #         key = os.getenv("DocIntellegenceKey")
    #         credential = AzureKeyCredential(key)
    #         client = DocumentAnalysisClient(endpoint=endpoint, credential=credential)
            
    #         poller = client.begin_analyze_document("prebuilt-read", img_stream)
    #         result = poller.result()

    #         extracted_text = []
    #         for page in result.pages:
    #             for line in page.lines:
    #                 extracted_text.append(line.content)
            
    #         return True, " ".join(extracted_text), ""
    #     except Exception as ex:
    #         logging.error(f"DocIntKWFromImg: {ex}")
    #         return False, "", str(ex)


    # def loaddocuments(container_name="asa-literature-policy-notes", prefix=""):
    #     loader = AzureBlobStorageContainerLoader(conn_str=os.getenv('AzureWebJobsStorage'),
    #                                      container=container_name,prefix=prefix)
             
    #         # template_cntry_mapping
    #     documents = loader.load()
    #     return documents

    if __name__ =='__main__':
        newFile = r'C:\Users\WB600054\Projects\Documents\MOP\Set 1\MOP-KDSP II_AFEDE_R1.docx'
        uploadBlobToContainer(newFile,'Test2','data/doc-mop/P123/raw')
    