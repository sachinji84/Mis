import os
from fastapi import Request, HTTPException
import msal
from starlette.status import HTTP_401_UNAUTHORIZED

from util.encryptdecrypt import decrypt
from .get_config import get_env_value
import logging
# from logging_functions.app_insights import logging

from azure.identity import DefaultAzureCredential

def int_utils_example_function(ex_parameter : str):
    logging.info('This is an example function which returns the parameter appended to a string.')
    return f"This is a return statement from integration_utils with parameter - {ex_parameter}"

class TokenHelper:
    @staticmethod
    def get_token_from_headers(user_current_token: str, resource_url: str) -> str:
        user_access_token = ""
        try:
            if user_current_token:
                user_current_token = user_current_token.replace("bearer", "").replace("Bearer", "").strip()
                if user_current_token:
                    user_access_token = TokenHelper.get_access_token_using_token(user_current_token, resource_url) or ""
        except Exception as ex:
            raise ex
        return user_access_token
    
    @staticmethod
    def get_access_token(req: Request, scope: str):
        current_access_token = req.headers.get("Authorization", None)
        if current_access_token is not None:
            scopes = [F"{scope}/.default"]
            clientId = get_env_value("OpsEcoClientId")
            clientSecreat = get_env_value("OpsEcoClientSecret")
            authority = "https://login.microsoftonline.com/31a2fec0-266b-4c67-b56e-2796d8f59c36"
            app = msal.ConfidentialClientApplication(
                clientId, clientSecreat, authority)
            result = app.acquire_token_on_behalf_of(
                user_assertion=current_access_token.split(' ')[1],
                scopes=scopes
            )
            if "access_token" in result:
                return result["access_token"]
            else:
                logging.info(f"get_access_token for {scope} failed -> {result.get('error_description')}")
                raise HTTPException(status_code=HTTP_401_UNAUTHORIZED, detail=f"get_access_token for {scope} failed" + str({'error': result.get("error"), 'error description': result.get("error_description")}))
        else:
            raise HTTPException(status_code=HTTP_401_UNAUTHORIZED, detail="Not authenticated : Missing token",
                                headers={"WWW-Authenticate": "Bearer"})
    
    @staticmethod
    def get_access_token_using_token(current_access_token: str, scope: str):
        if current_access_token is not None:
            scopes = [F"{scope}/.default"]
            clientId = get_env_value("OpsEcoClientId")
            clientSecreat = get_env_value("OpsEcoClientSecret")
            authority = "https://login.microsoftonline.com/31a2fec0-266b-4c67-b56e-2796d8f59c36"
            app = msal.ConfidentialClientApplication(
                clientId, clientSecreat, authority)
            result = app.acquire_token_on_behalf_of(
                user_assertion=current_access_token,
                scopes=scopes
            )
            if "access_token" in result:
                return result["access_token"]
            else:
                logging.info(f"get_access_token for {scope} failed -> {result.get('error_description')}")
                raise HTTPException(status_code=500, detail=f"get_access_token for {scope} failed" + str({'error': result.get("error"), 'error description': result.get("error_description")}))
        else:
            raise HTTPException(status_code=HTTP_401_UNAUTHORIZED, detail="Not authenticated",
                                headers={"WWW-Authenticate": "Bearer"})

    @staticmethod
    def get_token_using_mi(scope):
        try:
            credential = DefaultAzureCredential()
            token = credential.get_token(scope)
            access_token = token.token
            logging.info(f'Managed Identity token for scope {scope} -> succeeded')
            return access_token
        except Exception as e:
            logging.info(f"get_token_using_mi Exception {e}")
    

    @staticmethod
    def get_access_token_ops_workspace( scope: str):
        current_access_token = None
        if current_access_token is None:
            scopes = [F"{scope}/.default"]
            # clientId = get_env_value("OpsEcoClientId")
            # clientSecreat = get_env_value("OpsEcoClientSecret")
            # authority = "https://login.microsoftonline.com/31a2fec0-266b-4c67-b56e-2796d8f59c36"
            app = msal.ConfidentialClientApplication(
               client_id=os.getenv("CLIENT_ID"),
            authority=os.getenv("AUTHORITY"),
            client_credential=decrypt(os.getenv("CLIENT-SECRET")))
            # result = app.acquire_token_on_behalf_of(
            #     user_assertion=current_access_token.split(' ')[1],
            #     scopes=scopes
            # )
            result = app.acquire_token_silent(scopes, account=None)
            if not result:
                result = app.acquire_token_for_client(scopes=scopes)
            if "access_token" in result:
                return result["access_token"]
            else:
                logging.info(f"get_access_token for {scope} failed -> {result.get('error_description')}")
                raise HTTPException(status_code=HTTP_401_UNAUTHORIZED, detail=f"get_access_token for {scope} failed" + str({'error': result.get("error"), 'error description': result.get("error_description")}))
        else:
            raise HTTPException(status_code=HTTP_401_UNAUTHORIZED, detail="Not authenticated : Missing token",
                                headers={"WWW-Authenticate": "Bearer"})
