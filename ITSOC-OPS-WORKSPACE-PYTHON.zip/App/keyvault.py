import os
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor
import logging
load_dotenv()

def getSecrets():
    keyVaultName = os.environ["KEY_VAULT_NAME"]
    KVUri = f"https://{keyVaultName}.vault.azure.net"

    credential = DefaultAzureCredential()
    client = SecretClient(vault_url=KVUri, credential=credential)
    logging.error(f"Retrieving your secret from $ {keyVaultName}")

    retrieved_secrets = client.list_properties_of_secrets()
    logging.info(retrieved_secrets)
    for secret_property in retrieved_secrets:
        logging.info(secret_property.name)
        logging.info(f"Retrieving your secret from $ {keyVaultName}")
    secrets = ["AWS-ACCESS-KEY","AWS-SECRET-ACCESS-KEY","CLIENT-SECRET","AZURE-FORM-RECOGNIZER-KEY","BLOB-CONNECTION-STR","POSTGRES-DATABASE-URL"]
    # executor = ThreadPoolExecutor(max_workers=len(secrets))
    # data  = [executor.submit(client.get_secret(i)) for i in secrets]
    for i in secrets:
        try:
            os.environ[i]  = client.get_secret(i).value
            logging.error("**"+ i)
            logging.error("***"+os.environ[i])
        except Exception as  e:
            logging.error(e)
    logging.info(" done.")
    logging.error(f"Retrieving your secret from ")
    return "Success"

