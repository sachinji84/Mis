from cryptography.fernet import Fernet
from dotenv import load_dotenv
import os
load_dotenv(os.path.dirname(__file__)+"/.env")

key=os.getenv("FERNET_KEY")
cipher = Fernet(key)

def encrypt(text):
    
    encrypted_text = cipher.encrypt(text.encode())
    return encrypted_text

def decrypt(encrypted_text):
    decrypted_text = cipher.decrypt(bytes(encrypted_text,"UTF-8")).decode()
    return decrypted_text

# Example string
text = ""

# Encrypt the string
# encrypted_text = encrypt(text)
# print("Encrypted:", encrypted_text)
# decrypt_text = decrypt(encrypted_text)
# print("Decrypt:", decrypt_text)
