
from typing import List
from langchain.embeddings.base import Embeddings

from msal import ConfidentialClientApplication
import json
import requests
from concurrent.futures import ThreadPoolExecutor



class CustomEmbeddings(Embeddings):

    @classmethod
    def embed_documents_bycallingazureAI_API(self, payloadobj):
        print(payloadobj)
        responsen = requests.post("https://opssearchapimqa.worldbank.org/conversationalai/api/getEmbeddingData",
                                  json=payloadobj, headers=self.headers)        
        return json.loads(responsen.text)['output']

    @classmethod
    def embed_documents_bycallingazureAI_API1(self, payloadobj):
        print(payloadobj)
        responsen = requests.post("https://opssearchapimqa.worldbank.org/conversationalai/api/getEmbeddingData",
                                  json=payloadobj, headers=self.headers)
        return json.loads(responsen.text)['output']

    @classmethod
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        app = ConfidentialClientApplication(
            client_id="2526b799-f08d-4096-be93-9e159e6b3380",
            authority="https://login.microsoftonline.com/31a2fec0-266b-4c67-b56e-2796d8f59c36",
            client_credential="Ol88Q~6rG0zBJAaKC5G1BRfhTMNaH~Q4zBMqScA8"
        )
        SCOPE = ["c626bd72-9ef7-4efe-9176-5c75800f7670/.default"]
        result = app.acquire_token_silent(SCOPE, account=None)
        if not result:
            result = app.acquire_token_for_client(scopes=SCOPE)

        access_token = result['access_token']
        # payload = {"query":"waht is java"}
        headers = {"Ocp-Apim-Subscription-Key": "",
                   "Authorization": "Bearer "+access_token}
        self.headers = headers
        executor = ThreadPoolExecutor(max_workers=len(texts))
        data  = [executor.submit(self.embed_documents_bycallingazureAI_API,{"text": i}) for i in texts]

        embeddingsdata = [i.result() for i in data]
        return embeddingsdata


    @classmethod
    def embed_query(self, text: str) -> List[float]:
        app = ConfidentialClientApplication(
        client_id="2526b799-f08d-4096-be93-9e159e6b3380",
        authority="https://login.microsoftonline.com/31a2fec0-266b-4c67-b56e-2796d8f59c36",
        client_credential="Ol88Q~6rG0zBJAaKC5G1BRfhTMNaH~Q4zBMqScA8"
        )
        SCOPE = ["c626bd72-9ef7-4efe-9176-5c75800f7670/.default"]
        result = app.acquire_token_silent(SCOPE, account=None)

        if not result:
            result = app.acquire_token_for_client(scopes=SCOPE)

        access_token = result['access_token']
        headers = {"Ocp-Apim-Subscription-Key": "",
                   "Authorization": "Bearer "+access_token}
        payload1 = {"text": text}
        response1 = requests.post("https://opssearchapimqa.worldbank.org/conversationalai/api/getEmbeddingData",
                                  json=payload1, headers=headers)
        return json.loads(response1.text)['output']
